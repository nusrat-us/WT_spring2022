<?php
    session_start();
    $fname=$lname=$dob=$mobile="";

    if(!empty($_SESSION["fname"]))
    {
        $fname=$_SESSION["fname"];
        $lname=$_SESSION["lname"];
        $dob=$_SESSION["dob"];
        $mobile=$_SESSION["mobile"];
    }


    include("../control/admin_registration_check.php");
?>

<html>
    <head>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src = "js/jquery.js"></script>
        <link rel="stylesheet" href="../css/style.css"></link>
        <link rel="stylesheet" href="../css/style1.css"></link>
        <script src = "../js/admin_login_check.js"></script>
        <h1>Admin Registration Form</h1>

    </head>
    <hr>
    <body>
        <div class="login_reg">
            <form method = "POST" action ="">
                <table>
                    <tr>
                        <td><label for = "fname" >First Name:</td>
                        <td><input type = "text" id = "fname" name = "fname" value="<?php echo $fname ?>"></td>
                        <td><?php echo $validatefname ?> </td>
                    </tr>
                    <tr>
                        <td><label for = "lname" >Last Name:</td>
                        <td><input type = "text" id = "lname" name = "lname" value="<?php echo $lname ?>"></td>
                        <td><?php echo $validatelname ?> </td>
                    </tr>
                    <tr>
                        <td><label for = "mobile" >Mobile Number:</td>
                        <td><input type = "tel" id = "mobile" name = "mobile" value="<?php echo $mobile ?>"></td>
                        <td><?php echo $validatemobile ?> </td>
                    </tr>
                    <tr>
                        <td><label for = "dob" >Date of birth:</td>
                        <td><input type = "date" id = "dob" name = "dob" value="<?php echo $dob ?>"></td>
                        <td><?php echo $validatedate ?> </td>
                    </tr>


                    <tr>
                        <td><input type="submit" class="login_reg_button" name = "back" value="Back"></td>
                        <td><input type = "submit" class="login_reg_button" name = "next1" value = "Next"></td>
                    </tr>
                </table>
            </form>
            <p id="err1"></p>
        </div>                
    </body>
</html>