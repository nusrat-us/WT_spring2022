<?php
include('../model/db.php');
$radio1=$radio2=$radio3=$radioValidation="";
$uname=$fname=$lname= $age=$uid=$email=$successmessage="";
 if(isset($_POST["search"]))
 {
     
$uname=$_POST["uname"];
   
 $connection = new db();
 $conobj=$connection->OpenCon();
 
 $userQuery=$connection->searchAccountHolder($conobj,"account_holder",$uname);
 
 
 if ($userQuery !== false && $userQuery->num_rows > 0)
  {
 
     // output data of each row
     while($row = $userQuery->fetch_assoc()) 
     {
       $fname=$row["fname"];
       $lname=$row["lname"];
       $age=$row["age"];
       $uid=$row["uid"];
       $email=$row["email"];

       if(  $row["account"]=="Normal Account" )
       { $radio1="checked"; }
       else if($row["account"]=="Saving Account")
       { $radio2="checked"; }
       else if($row["account"]=="Checking Account")
       { $radio3="checked"; }
       else
       {
        $radioValidation="Nothing was checked";

       }
      
      // $acctype=$row["account"];
      
 }
}
 }
   


 if(isset($_POST["update"]))
 {
       
       $uname=$_POST['uname'];
       $fname=$_POST['fname'];
       $lname=$_POST['lname'];
       $age=$_POST['age'];
       $uid=$_POST['uid'];
       $email=$_POST['email'];
       //$acctype=$_POST['acctype'];
       
    $connection = new db();
    $conobj=$connection->OpenCon();
 
    $userQuery=$connection->UpdateAccHolder($conobj,"account_holder",$uname,$fname,$lname,$age,$uid,$email,$_POST['acctype']);
 
 
 if ($userQuery==TRUE) {
 
    $successmessage= "Update Successful ! ";
    
   } 
 
   else {

    $successmessage="Could not update!";
    
    
   }
   $connection->CloseCon($conobj);




 

 }


 

?>
