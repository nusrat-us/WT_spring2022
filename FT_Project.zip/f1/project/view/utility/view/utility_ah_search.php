<html>
    <head>
        <link rel="stylesheet" href="../css/style.css">
        <h2>Search Account Holder</h2>
    </head>
    <hr>
    <body>
        <script src="../js/validate.js"></script>
        Search Account holder: <input type="text" name="uname" id="uname" placeholder="Search..."><br>
        <button id="search" onclick="search_ah()">Search</button>
        <a href="utility.php">Back</a>
        <br>
        <p id="text"></p>
    </body>
</html>