<?php
    session_start();
    include("../admin/control/admin_login_check.php")
?>

<html>
    <head>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src = "js/jquery.js"></script>
        <link rel="stylesheet" href="css/style.css"></link>
        <link rel="stylesheet" href="css/style1.css"></link>
        <script src = "js/admin_login_check.js"></script>
        
        <h1>Admin Login Page</h1>        
    </head>
    <hr>
    <body>
        <div class="login_reg">
            <form onsubmit ="return admin_login_check()" method="POST">
                <table>
                    <tr>
                        <td><?php echo $validateuname ?></td>
                        <td><?php echo $validatepwd ?></td>
                    </tr>
                    <tr>
                        <td><input type = "text" id ="uname" name = "uname" placeholder = "Username"></td>
                    </tr>
                    <tr>
                        <td><br></td>
                    </tr>
                    <tr>                      
                        <td><input type = "password" id = "pwd" name = "pwd" placeholder = "Password"></td>
                    </tr>
                    <tr>
                        <td><input type = "checkbox" name = "remember">
                            <label for = "remember">Remember Me</td>
                    </tr>
                    <tr>
                        <td><input type = "submit" class="login_reg_button" name= "submit" value = "Login"></td>
                    </tr>
                </table>
            </form>
          
            <p id="error"></p>
            <h4>Become an <a href = "../admin/view/admin_registration.php">Admin?</a></h4>
            <h4><a href = "../Homepage.php">Homepage</a></h4>  
        </div>   
    </body>
</html>