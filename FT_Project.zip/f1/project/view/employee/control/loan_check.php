<?php
include('../model/db.php');
//session_start();

  
    $connection = new db();
    $conobj=$connection->OpenCon();
    
    $userQuery=$connection->LoanDetail($conobj,"bank_loan");
    $connection->CloseCon($conobj);

  

 ?>
 