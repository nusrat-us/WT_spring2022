<?php
    session_start();
    $msg1="";
    require("../model/db.php");
?>
<html>
    <head>
        <link rel="stylesheet" href="../css/style.css">
        <h1>Account Holders</h1>
        <hr>        
    </head>
    <body>
<?php    
    $connection = new db();
    $conobj = $connection->OpenCon();

    $userQuery = $connection->ShowAll($conobj,"account_holder");

    if($userQuery !== false && $userQuery->num_rows > 0)
    {     
        echo "<table><tr><th>ID</th><th>First Name</th><th>Last Name</th><th>Age</th><th>Username</th><th>Email</th><th>Password</th><th>Account Type</th></tr>";
        while($row = $userQuery->fetch_assoc())
        {
            echo "<tr><td>".$row["id"]."</td><td>".$row["fname"]."</td><td>".$row["lname"]."</td><td>".$row["age"]."</td><td>".$row["uname"]."</td><td>".$row["email"]."</td><td>".$row["pwd"]."</td><td>".$row["account"]."</td></tr>";
        }
        echo "</table>";
    } 
    else 
    {
        echo "0 results";
    }
?>
    <hr>
    <a href="utility.php">Back</a>
    </body>
</html>
