<?php
    session_start();
    include("../control/utility_registration_check.php");
?>

<html>
    <head>
        <link rel="stylesheet" href="../css/style.css">
        <h1>Utility Registration Form</h1>

    </head>
    <hr>
    <body>      
            <form method = "POST" action ="">
                <table>
                    <tr>
                        <td><label for = "fname" >First Name:</td>
                        <td><input type = "text" id = "fname" name = "fname"></td>
                        <td><?php echo $validatefname ?> </td>
                    </tr>
                    <tr>
                        <td><label for = "lname" >Last Name:</td>
                        <td><input type = "text" id = "lname" name = "lname"></td>
                        <td><?php echo $validatelname ?> </td>
                    </tr>
                    <tr>
                        <td><label for = "mobile" >Mobile Number:</td>
                        <td><input type = "tel" id = "mobile" name = "mobile"></td>
                        <td><?php echo $validatemobile ?> </td>
                    </tr>
                    <tr>
                        <td><label for = "dob" >Date of birth:</td>
                        <td><input type = "date" id = "dob" name = "dob"></td>
                        <td><?php echo $validatedate ?> </td>
                    </tr>
                    <tr>
                        <td><label for = "uname" >UserName:</td>
                        <td><input type = "text" id = "uname" name = "uname"></td>
                        <td><?php echo $validateuname ?> </td>
                    </tr>
                    <tr>
                        <td><label for = "email" >Email:</td>
                        <td><input type = "email" id = "email" name = "email"></td>
                        <td><?php echo $validateemail ?> </td>
                    </tr>
                    <tr>
                        <td><label for = "pwd" >Password:</td>
                        <td><input type = "password" id = "pwd" name = "pwd"></td>
                        <td><?php echo $validatepwd ?> </td>
                    </tr>
                    <tr>
                        <td><input type = "submit" name = "next1" value = "Next"></td>
                        <td><a href = "../utility_login.php">Back</a></td>
                    </tr>
                </table>
            </form>                      
    </body>
</html>