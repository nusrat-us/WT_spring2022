<?php

include('../model/db.php');
 

$addSuccess="";
$Fname=$Lname=$Age=$Uname=$Uid=$Email=$Password="";


if (isset($_POST['add'])) 
{
    $Fname=$_POST['fname'];
    $Lname=$_POST['lname'];
    $Age=$_POST['age'];
    $Uname=$_POST['uname'];
    $Uid=$_POST['uid'];
    $Email=$_POST['email'];
    $Password=$_POST['pwd'];
    //$AccType=$_POST['acctype'];

    
        $connection = new db();
        $conobj=$connection->OpenCon();
    
        $userQuery=$connection->InsertAccountHolder($conobj,"account_holder",$Fname,$Lname,$Age,$Uname,$Uid,$Email,$Password,$_POST['acctype']);

        if ($userQuery==TRUE)
         {
 
            $addSuccess= "Added Successfuly ! ";
            
           }

          
         
        $connection->CloseCon($conobj);
    
}


?>