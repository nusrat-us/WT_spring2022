<?php
    session_start();
    include("../control/ah_reg1_check.php");
?>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="../CSS/style1.css">
        <script src = "../js/validation.js"></script>
        <h2>Account Holder Registration Form</h2>
        <hr>
    </head>
    <body>
        <div class ="ah_login_reg">
            <form onsubmit="return ah_reg1_check()" method="POST">
                <input type="text" name="fname" id="fname" placeholder="Firstname"><?php echo $validatefname ?>
                <br><br>
                <input type="text" name="lname" id="lname" placeholder="Lastname"><?php echo $validatelname ?>
                <br><br>
                Date of Birth<br>                  
                <input type="date" name="dob" id="dob"><?php echo $validatedob ?>
                <br><br>
                <a href="ah_login.php">Back</a>

                <input type="submit" name="submit" value="Next"> 
            </form>
            <p id="err2"></p>
        </div> 
    </body>
</html>