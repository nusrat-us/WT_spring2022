<DOCTYPE html>
    <html>
        <head>
            <h1>
                <center>Bank name</center>
            </h1>
            <hr>
            <body>
                <center>
                <table>
                    <tr>
                        <td><h3><a href="../view/admin/admin_login.php">ADMIN</a>||</h3></td>
                        <td><h3><a href="../view/employee/view/HomePage.php">EMPLOYEE</a>||</h3></td>
                        <td><h3><a href="../view/account_holder/view/ah_login.php">ACCOUNT HOLDER</a>||</h3></td>
                        <td><h3><a href="../view/utility/utility_login.php">UTILITY</a></h3></td>                      
                    </tr>
                </table>
                
                <hr>
                <?php

                    $data = file_get_contents("../view/admin/control/data.json");
                    $mydata = json_decode($data);
                    
                    foreach($mydata as $myobject)
                    {
                        foreach($myobject as $key=>$value)
                        {
                            for($i = 0;$i<1;$i++)
                            {
                                echo $key.": ".$value."<br>";
                                break;
                            }
                            break;
                            
                        } 
                        break;

                    }
                    // $footer = $mydata;

                    // echo "Notice: ".$footer;
                ?>
                <br>
                <br>
                <?php
                    $data = file_get_contents("../view/utility/control/data.json");
                    $mydata = json_decode($data);
                    
                    foreach($mydata as $myobject)
                    {
                        foreach($myobject as $key=>$value)
                        {
                            for($i = 0;$i<1;$i++)
                            {
                                echo $key.": ".$value."<br>";
                                break;
                            }
                            break;                           
                        } 
                        break;
                    }
                ?>
                </center>
            </body>
        </head>
    </html>
