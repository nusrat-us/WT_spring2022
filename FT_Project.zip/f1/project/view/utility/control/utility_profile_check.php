<?php
    
    $id=$fname=$lname=$mobile=$dob=$uname=$email=$pwd=$msg="";

    if(isset($_POST["update"]))
    {
        $id = $_POST["id"];
        $fname = $_POST["fname"];
        $lname = $_POST["lname"];
        $mobile = $_POST["mobile"];
        $dob = $_POST["dob"];
        $uname = $_POST["uname"];
        $email = $_POST["email"];
        $pwd = $_POST["pwd"];

        $connection = new db();
        $conobj=$connection->OpenCon();
        $userQuery=$connection->Update_utility($conobj,"utility", $id, $fname, $lname, $mobile, $dob, $uname, $email, $pwd);

        if($conobj->query($userQuery) != TRUE) 
        {
            $msg = "Updated successfully!";

            $_SESSION["fname"]=$_POST["fname"];
            $_SESSION["lname"]=$_POST["lname"];
            $_SESSION["mobile"]=$_POST["mobile"];
            $_SESSION["dob"]=$_POST["dob"];
            $_SESSION["uname"]=$_POST["uname"];
            $_SESSION["email"]=$_POST["email"];
            $_SESSION["pwd"]=$_POST["pwd"];
        }
        else 
        {
            $msg = "Update Failed!";
        }  
    }
?>