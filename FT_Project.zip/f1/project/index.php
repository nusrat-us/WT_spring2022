<?php
    header("location: view/Homepage.php");
?>