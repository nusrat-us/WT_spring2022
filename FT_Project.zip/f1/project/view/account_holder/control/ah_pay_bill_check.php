<?php
    require("../model/db.php");
    $uname=$amount=$bill=$month=$msg="";

    if(isset($_POST["pay"]))
    {
        if(!empty($_POST["amount"]))
        {
            $uname=$_POST["uname1"];
            $amount=$_POST["amount"];
            $bill=$_POST["bill"];
            $month=$_POST["month"];
            $connection = new db();

            $conobj=$connection->Opencon();

            $userQuery=$connection->bill_pay($conobj,"pay_bill",$uname,$amount,$bill,$month);

            if($conobj->query($userQuery) != TRUE)
            {
               $msg="Bill paid succesfully";

            }
            else
            {
                $msg =  "Error: " . $userQuery . "<br>" . $conobj->error;
            }

            $connection->Closecon($conobj);
        }
        
    }
?>