<html>
    <head>
        <link rel="stylesheet" href="../css/style.css">
        <h2>Search Users</h2>
    </head>
    <hr>
    <body>
        <div class="navbar">
            <a href = "../view/admin.php">Home</a>
            <a href = "../view/admin_search.php">Search Profiles</a>
            <div class="dropdown">
                <button class="dropbtn">Update and Delete users
                </button>
                <div class="dropdown-content">
                <a href = "../view/admin_ah.php">Account Holders</a>
                <a href = "../view/admin_emp.php">Employees</a>
                <a href = "../view/admin_utility.php">Utility</a>
                </div>
            </div>
            <div class="dropdown">
                <button class="dropbtn">Account
                </button>
                <div class="dropdown-content">
                <a href = "../view/admin_profile.php">Profile</a>
                <a href = "../control/logout.php">Log out</a>
                </div>
            </div>
        </div>
        <br>
        <script src="../js/admin_login_check.js"></script>
        Search Account holder: <input type="text" name="uname" id="uname" placeholder="Search..."><br>
        <button id="search" onclick="showmyuser()">Search</button>
        <br>
        <p id="mytext"></p>
        <br><br><br><br><br><br><br>
        <hr>
        Search Employee: <input type="text" name="uname1" id="uname1" placeholder="Search..."><br>
        <button id="search1" onclick="showmyuser1()">Search</button>
        <br>
        <p id="mytext1"></p>
        <br><br><br><br><br><br><br>
        <hr>
        Search Utility: <input type="text" name="uname2" id="uname2" placeholder="Search..."><br>
        <button id="search2" onclick="showmyuser2()">Search</button>
        <br>
        <p id="mytext2"></p>

    </body>
</html>