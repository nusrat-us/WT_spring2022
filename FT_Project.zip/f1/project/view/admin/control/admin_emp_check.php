<?php
    $msg=$fname=$lname=$gender=$dob=$uname=$id=$email=$pwd=$jobpos="";
    
    if(isset($_POST["enter"]))
    {
        $connection = new db();
        $conobj=$connection->OpenCon();
        $userQuery=$connection->Check_ah($conobj,"employee",$_POST["id"]);
        
        
        if($userQuery !== false && $userQuery->num_rows > 0) 
        {
            while($row = $userQuery->fetch_assoc()) 
            {
                $id = $row["id"];
                $fname = $row["fname"];
                $lname = $row["lname"];
                $gender = $row["gender"];
                $dob = $row["dob"];
                $email = $row["email"];
                $jobpos = $row["jobpos"];
                $uname = $row["uname"];
                $pwd = $row["pwd"];
            }
        } 
        else 
        {
            $msg1= "0 results";
        }
    }

    if(isset($_POST["update"]))
    {
        $id = $_POST["id1"];
        $fname = $_POST["fname"];
        $lname = $_POST["lname"];
        $gender = $_POST["gender"];
        $dob = $_POST["dob"];
        $email = $_POST["email"];
        $jobpos = $_POST["jobpos"];
        $uname = $_POST["uname"];
        $pwd = $_POST["pwd"];

        $connection = new db();
        $conobj=$connection->OpenCon();
        $userQuery=$connection->Update_emp($conobj,"employee", $id, $fname, $lname, $gender, $dob, $email, $jobpos, $uname, $pwd);

        if($conobj->query($userQuery) != TRUE) 
        {
            $msg = "Updated successfully!";
        }
        else 
        {
            $msg = "Update Failed!";
        }
     
    }

    if(isset($_POST["delete"]))
    {
        $id = $_POST["id1"];
        $fname = $_POST["fname"];
        $lname = $_POST["lname"];
        $gender = $_POST["gender"];
        $dob = $_POST["dob"];
        $email = $_POST["email"];
        $jobpos = $_POST["jobpos"];
        $uname = $_POST["uname"];
        $pwd = $_POST["pwd"];

        $connection = new db();
        $conobj=$connection->OpenCon();
        $userQuery=$connection->Delete($conobj,"employee", $uname);

        if($conobj->query($userQuery) != TRUE) 
        {
            $msg = "Deleted Successfully!";
        }
        else 
        {
            $msg = "Delete Failed!";
        }
     
    }
?>