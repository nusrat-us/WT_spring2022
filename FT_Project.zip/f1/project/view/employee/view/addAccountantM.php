<?php
include('../control/addAccountantMCheck.php');

/*if(isset($Fname) && isset($Lname) && isset($Age) && isset($Uname) && isset($Uid) && isset($Email) && isset($Password) && isset($AccType))
{
    $message= "Added Successfully !";
}*/
?>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="../CSS/updateaccholder.css">
</head>
<body>
<div class="header">
<h1>Add Accountant</h1>
</div>

<br><br>
<br><br>
<br><br>

<div class="middlecolumn">

<form action="" method="post" onsubmit="return AddAccountantFormVal()">
    <table>
        <tr>
            <td><label>First Name:</label></td>
            <td><input type="text" name="fname" id="fname">  </td> <td><p class="error" id="errorfname"></p></td>
        </tr>

        <tr>
            <td><label>Last Name:</label></td>
            <td><input type="text" name="lname" id="lname" ></td> <td><p class="error" id="errorlname"></p></td>
        </tr>

        <tr>
            <td><label> Gender:</label></td>
            <td>
            <input type="radio" id="Male" name="gender" value="Male">
            <label for="Male">Male</label>

            <input type="radio" id="Female" name="gender" value="Female">
            <label for="Female">Female</label>

                         
     
            </td> <td> <p class="error" id="errorgender"></p></td>
        </tr>

        <tr>
            <td><label>Date of Birth:</label></td>
            <td><input type="date" name="dob" id="dob"></td> <td> <p class="error" id="errordob"></p></td>
        </tr>

        <tr>
            <td><label>Mobile:</label></td>
            <td><input type="text" name="mobile" id="mobile"></td> <td> <p class="error" id="errormobile"></p></td>
        </tr>


        <tr>
            <td><label for="email">E-mail:</label></td>
            <td><input type="text" name="email" id="email"></td> <td> <p class="error" id="erroremail"></p></td>
        </tr>

        <tr>
            <td><label> Job Position:</label></td>
            <td>
            <input type="radio" id="Accountant" name="jobpos" value="Accountant">
            <label for="Accountant">Accountant</label>

            
            </td> <td> <p class="error" id="errorjobpos"></p></td>
        </tr>





        <tr>
            <td><label>Username:</label></td>
            <td><input type="text" name="username" id="username"></td> <td><p class="error" id="errorusername"></p></td>
        </tr>

        <tr>
            <td><label>Password:</label></td>
            <td><input type="password" name="password" id="password"></td><td><p class="error" id="errorpassword"></p></td>
        </tr>
        
            
           
        

</table>
<br>
<input type="submit" class="box1 add" name="add" value="Add">





</form>
<br><br>


<?php

if(!empty($message))
{
    echo "<div class='box success'>".$message."</div>";
}

?>

</div>
<footer>

<a class="two" href="../view/AccountantM.php">Previous Page</a>

<a class="one" href="../control/logout.php">Logout</a>
</footer>
<script src="../JS/myjs.js"></Script>
</body>
</html>


