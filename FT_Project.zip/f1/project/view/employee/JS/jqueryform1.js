$(document.body).css( {"background":"#EBDEF0  ","color":"#F4D03F","font-size":"20px"});

$(document).ready(function(){
      $(".RegistrationBox").css({"background-color":"#34495E  ","padding":"50px "});
    });


    $(document).ready(function() {
      $(".header").css({"width":"100%" ,"top":0,"background":"#FEF9E7","text-align":"center","font-size":"30px"});
  });

  


$(document).ready(function() {
    $(":header").css("color", "#154360");
});



$(document).ready(function(){
    $("input").focus(function(){
      $(this).css("background-color", "#FDEDEC");
    });
    $("input").blur(function(){
      $(this).css("background-color", "#FEF9E7 ");
    });
  });


  //document.getElementById("fname").onkeyup = function() {myFunction()};

/*function myFunction() {
  var x = document.getElementById("fname");
  x.value = x.value.toUpperCase();
}

$(document).ready(function(){
    $("#fname").onkeyup(function(){
      $(this).css("background-color", "#FDEDEC");
    });
    $("input").blur(function(){
      $(this).css("background-color", "#FEF9E7 ");
    });
  });*/

 /* $(document).ready(function(){
    $(":radio").wrap("<span style='background-color:yellow'>");
  });*/

  $(document).ready(function(){
    $(":submit").css({"background-color":"#F4F6F7","color":"#D35400","padding":"5px ","border-radius":"8px "});

  });

  $(document).ready(function(){
    $(":date").css("background-color", "#FDEDEC");
  });

  $(document).ready(function(){
    $("a").css({"background-color":"#922B21","color":"#F4F6F7","padding":"5px ","border-radius":"8px "});
  });

  $(document).ready(function(){
    $("h1").mouseenter(function(){
        $( "#titlepage1" ).text( "This is the First Page of registration !" ).css({"color":"#A04000","background-color":"#FEF9E7 ","font-size":"40px","text-align":"center" }).show();
    });
  });

  $(document).ready(function(){
    $("h1").mouseleave(function(){
        $( "#titlepage1" ).text( "This is the First Page of registration !" ).hide();
    });
  });

  $(document).ready(function(){
    $(":date").css("background-color", "#FDEDEC");
  });

  $(document).ready(function(){
    $("#errorfname,#errorlname,#errorgender,#errordob,#errormobile,#erroremail,#errorjobposition,#errorusername,#errorpassword").css("color","#C0392B");
  });

  /*$(document).ready(function(){
    $("#errorfname").css("color","#C0392B");
  });
  $(document).ready(function(){
    $("#errorlname").css("color", "#C0392B");
  });
  $(document).ready(function(){
    $("#errorgender").css("color", "#C0392B");
  });
  $(document).ready(function(){
    $("#errordob").css("color", "#C0392B");
  });
  $(document).ready(function(){
    $("#errormobile").css("color", "#C0392B");
  });
  $(document).ready(function(){
    $("#erroremail").css("color", "#C0392B");
  });

  $(document).ready(function(){
    $("#errorjobposition").css("color", "#C0392B");
  });
  $(document).ready(function(){
    $("#errorusername").css("color", "#C0392B");
  });
  $(document).ready(function(){
    $("#errorpassword").css("color", "#C0392B");
  });*/
 

  $(document).ready(function(){
    $("h1").mouseenter(function(){
        $( "#titlepage2" ).text( "This is the Second Page of registration !" ).css({"color":"#A04000","background-color":"#FEF9E7 ","font-size":"40px","text-align":"center" }).show();
    });
  });

  $(document).ready(function(){
    $("h1").mouseleave(function(){
        $( "#titlepage2" ).text( "This is the Second Page of registration !" ).hide();
    });
  });

  $(document).ready(function(){
    $("h1").mouseenter(function(){
        $( "#titlepage3" ).text( "This is the Final Page of registration !" ).css({"color":"#A04000","background-color":"#FEF9E7 ","font-size":"40px","text-align":"center" }).show();
    });
  });

  $(document).ready(function(){
    $("h1").mouseleave(function(){
        $( "#titlepage3" ).text( "This is the Final Page of registration !" ).hide();
    });
  });
  
  


