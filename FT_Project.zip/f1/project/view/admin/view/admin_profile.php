<?php
    session_start();
    include("../control/admin_profile_check.php");  
?>     
<html>
    <head>
        <link rel="stylesheet" href="../css/style.css">
        <h1>Profile of <?php echo $_SESSION["fname"]." ". $_SESSION["lname"] ?> </h1>
    </head>
    <hr>
    <body>
        <div class="navbar">
            <a href = "../view/admin.php">Home</a>
            <a href = "../view/admin_search.php">Search Profiles</a>
            <div class="dropdown">
                <button class="dropbtn">Update and Delete users
                </button>
                <div class="dropdown-content">
                <a href = "../view/admin_ah.php">Account Holders</a>
                <a href = "../view/admin_emp.php">Employees</a>
                <a href = "../view/admin_utility.php">Utility</a>
                </div>
            </div>
            <div class="dropdown">
                <button class="dropbtn">Account
                </button>
                <div class="dropdown-content">
                <a href = "../view/admin_profile.php">Profile</a>
                <a href = "../control/logout.php">Log out</a>
                </div>
            </div>
        </div>
        <br><br><br>
        <form action = "" method = "POST">
            <input type="hidden" name="id" id="id" value=<?php echo $_SESSION["id"] ?>>
            <table>
                <tr>
                    <td><label for = "fname" >First Name:</td>
                    <td><input type = "text" id = "fname" name = "fname" value =<?php echo $_SESSION["fname"]?>></td>               
                </tr>
                <tr>
                    <td><label for = "lname" >Last Name:</td>
                    <td><input type = "text" id = "lname" name = "lname" value =<?php echo $_SESSION["lname"]?>></td>                              
                </tr>
                <tr>
                    <td><label for = "mobile" >Mobile Number:</td>
                    <td><input type = "tel" id = "mobile" name = "mobile" value =<?php echo $_SESSION["mobile"]?>></td>                                
                </tr>
                <tr>
                    <td><label for = "dob" >Date of birth:</td>
                    <td><input type = "date" id = "dob" name = "dob" value =<?php echo $_SESSION["dob"]?>></td>               
                </tr>
                <tr>
                    <td><label for = "uname" >UserName:</td>
                    <td><input type = "text" id = "uname" name = "uname" value =<?php echo $_SESSION["uname"]?>></td>                              
                </tr>
                <tr>
                    <td><label for = "email" >Email:</td>
                    <td><input type = "email" id = "email" name = "email" value =<?php echo $_SESSION["email"]?>></td>                              
                </tr>
                <tr>
                    <td><label for = "pwd" >Password:</td>
                    <td><input type = "text" id = "pwd" name = "pwd" value =<?php echo $_SESSION["pwd"]?>></td>                              
                </tr>

            </table>
            <br>
            <input type ="submit" name="update" class="update2" Value="update">
        </form> 
        <?php echo $msg ?>     
    </body>
</html>


