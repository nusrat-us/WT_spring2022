<?php
include('../control/addAccInfoACheck.php');

/*if(isset($Fname) && isset($Lname) && isset($Age) && isset($Uname) && isset($Uid) && isset($Email) && isset($Password) && isset($AccType))
{
    $message= "Added Successfully !";
}*/
?>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="../CSS/updateaccholder.css">
</head>
<body>
<div class="header">
<h1>Add Account Information of Account Holder</h1>
</div>

<br><br>
<br><br>
<br><br>

<div class="middlecolumn">

<form action="" method="post" onsubmit="return AddAccInfoVal()">
    <table>
        <tr>
            <td><label>User Name:</label></td>
            <td><input type="text" name="uname" id="uname">  </td> <td><p class="error" id="erroruname"></p></td>
        </tr>

        <tr>
            <td><label>Bank Account No:</label></td>
            <td><input type="text" name="accNo" id="accNo" ></td> <td><p class="error" id="erroraccNo"></p></td>
        </tr>

        <tr>
            <td><label>Current Balance:</label></td>
            <td><input type="text" name="currbalance" id="currbalance"></td> <td> <p class="error" id="errorcurrbalance"></p></td>
        </tr>

        <tr>
            <td><label> Account Type:</label></td>
            <td>
            <input type="radio" id="Normal Account" name="acctype" value="Normal Account">
            <label for="Normal Account">Normal Account</label>
            <br>

            <input type="radio" id="Saving Account" name="acctype" value="Saving Account">
            <label for="Saving Account">Saving Account</label>
            <br>
            <input type="radio" id="Checking Account" name="acctype" value="Checking Account">
            <label for="Checking Account">Checking Account</label>
</td>

                        
            </td> <td> <p class="error" id="erroracctype"></p></td>
        </tr>
              

</table>
<br>
<input type="submit" class="box1 add" name="add" value="Add">





</form>
<br><br>

<?php

if(!empty($message))
{
    echo "<div class='box success'>".$message."</div>";
}

?>


</div>
<footer>

<a class="two" href="../view/AccountInfoA.php">Previous Page</a>

<a class="one" href="../control/logout.php">Logout</a>
</footer>
<script src="../JS/myjs.js"></Script>
</body>
</html>


