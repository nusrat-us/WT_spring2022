<?php
session_start();

$Fname="";
$valFname="";
$Lname="";
$valLname="";
//$Gender="";
$valradioGender="";
$Dob="";
$valDob="";
$Mobile="";
$valMobile="";
$Email="";
$valemail="";


if (isset($_POST['continue'])) 
{
    $Fname= $_POST['fname'];
    $Lname=$_POST['lname'];
    //$Gender=$_POST['gender'];
    $Dob=$_POST['dob'];
    $Mobile=$_POST['mobile'];
    $Email=$_POST['email'];

    if(!empty($Fname))
    {
        $_SESSION["firstname"]=$Fname;
    
    }

    else
    {
        $valFname="First Name can not be empty !";

    }
    
    if(!empty($Lname))
    {
        $_SESSION["lastname"]=$Lname;
    
    }
    else
    {
        $valLname="Last Name can not be empty !";

    }
    

    

    if(isset($_POST['gender']))
    {
        $_SESSION["gender"]=$_POST['gender'];
    
    }

    else
    {
        $valradioGender="Please select your gender !";

    }

    
    if(!empty($Dob))
    {
        $_SESSION["Dob"]=$Dob;
    
    }

    else
    {
        $valDob="Date of Birth can not be empty !";

    }

    if(!empty($Mobile))
    {
        $_SESSION["mobile"]=$Mobile;
    
    }

    else
    {
        $valMobile="Mobile No can not be empty !";

    }

    

    if(!empty($Email) || preg_match("/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/ix",$Email))
    {
        $_SESSION["email"] =$Email;
    
    }

    else
    {
        $valemail="Email can not be empty !";

    }



}
?>