<?php
session_start(); 

include('../control/editProfileCheck.php');


if(empty($_SESSION["username"])) 
{
header("Location: ../view/login.php");
}

?>

<!DOCTYPE html>
<html>

    <head>
        <link rel="stylesheet" type="text/css" href="../CSS/updateaccholder.css">
    </head>

<body>

    <div class="header">
        <h2>Edit Profile Information</h2>
        <h4><?php echo $_SESSION["username"];?></h4>

    </div>

<br><br>
<br><br>
<br><br>

    <div class="middlecolumn">
        <form action='' method='post'>
            <br><br>
            <table >
                <tr>
                    <th><label>First Name :</label></th>
                    <th> <input type='text' name='fname' value="<?php echo $fname; ?>" ></th>
                </tr>
                <tr>
                    <th><label>Last Name :</label></th>
                    <th> <input type='text' name='lname' value="<?php echo $lname; ?>" ></th>
                </tr>
                <tr>

                    <th><label>Gender:</label> <?php echo $radioValidation; ?></th>
                       
                    <th> 
                    <input type='radio' name='gender' value='Male'<?php echo $radio1; ?>>Male
                    <input type='radio' name='gender' value='Female' <?php echo $radio2; ?> >Female 
                    </th>   

                </tr>
                <tr>
                    <th><label>DOB :<label></th>
                    <th> <input type='date' name='dob' value="<?php echo $dob; ?>" ></th>
                </tr>
                <tr>
                    <th><label>E-mail : </label></th>
                    <th><input type='email' name='email' value="<?php echo $email; ?>" > </th>
                </tr>

            </table>

            <br><br>

                <input type='submit' class="box1 update"  name='update' value='Confirm Edit'> 
        </form>

        <?php

        if(!empty($message))
        {
            echo "<div class='box success'>".$message."</div>";
        }

        ?>

        

        
    </div>
        <br>


<footer>

<a class="two" href="../view/ManagerPage.php">Previous Page</a>

<a class="one" href="../control/logout.php">Logout</a>
</footer>



</body>
</html>

