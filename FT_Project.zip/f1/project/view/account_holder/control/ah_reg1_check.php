<?php
    $validatefname="";
    $validatelname="";
    $validatedob="";
    
    if(isset($_POST["submit"]))
    {
        $_SESSION["fname"]=$_POST["fname"];
        $_SESSION["lname"]=$_POST["lname"];
        $_SESSION["dob"]=$_POST["dob"];
        if(empty($_SESSION["fname"]))
        {
            $validatefname="Enter your first name please!";
        }
        else
        {
            $validatefname="";
        }

        if(empty($_SESSION["lname"]))
        {
            $validatelname="Enter your last name please!";
        }
        else
        {
            $validatelname="";
        }


        if(empty($_SESSION["dob"]))
        {
            $validatedob="Enter your date of birth please!";
        }
        else
        {
            $validatedob="";
        }

        if($validatefname=="" && $validatelname=="" && $validatedob=="")
        {
            header("location: ../view/ah_reg2.php");
        }
    }
?>
