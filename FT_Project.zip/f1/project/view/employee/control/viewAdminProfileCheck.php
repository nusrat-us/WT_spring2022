<?php
include('../model/db.php');
session_start(); 



$connection = new db();
$conobj=$connection->OpenCon();

$username=$_SESSION["username"];

$userQuery=$connection->viewAdminProfile($conobj,"admin");
$connection->CloseCon($conobj);
?>