<?php

include('../model/db.php');

session_start(); 

//$Jobpos="";
$valJobpos="";
$Uname="";
$valUname="";
$password="";
$valpass="";


if (isset($_POST['Confirm'])) 
{
    //$Jobpos= $_POST['jobposition'];
    $Uname=$_POST['username'];
    $password=$_POST['password'];
  

    if(isset($_POST['jobposition']))
    {
        $_SESSION["Jobpos"]=$_POST['jobposition'];
    
    }

    else
    {
        $valJobpos="Please select a Job Position";

    }
    if(!empty($Uname))
    {
        $_SESSION["username"]=$Uname;
    
    }

    else
    {
        $valUname="Username is required";

    }

    if( !empty($password))
    {
        $_SESSION["Password"]=$password;
    
    }

    else
    {
        $valpass="Password is required";

    }

    $connection = new db();
    $conobj=$connection->OpenCon();

    $userQuery=$connection->InsertRegisteredData($conobj,"employee",$_SESSION["firstname"],$_SESSION["lastname"],$_SESSION["gender"],$_SESSION["Dob"],$_SESSION["mobile"],$_SESSION["email"],$_SESSION["Jobpos"],$_SESSION["username"],$_SESSION["Password"] );

    $connection->CloseCon($conobj);

}


?>