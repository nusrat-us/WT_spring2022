<?php
    class db
    {
        function OpenCon()
        {
            $dbhost = "localhost";
            $dbuser = "root";
            $dbpass = "";
            $db = "bank";
    
            $conn = new mysqli($dbhost, $dbuser, $dbpass, $db);

            return $conn;
        }

        function CheckUser($conn, $table, $username, $password)
        {
            $result = $conn->query("SELECT * FROM ". $table." WHERE uname='". $username."' AND pwd='". $password."'");
            return $result;
        }

        function ShowAll($conn,$table)
        {
            $result = $conn->query("SELECT * FROM $table");
            return $result;
        }

        function ViewProfile($conn,$table,$uname)
        {
            $result = $conn->query("SELECT * FROM ". $table." WHERE uname='". $uname."'");
            return $result;
        }

        function Update_utility($conn, $table, $id, $fname, $lname, $mobile, $dob, $uname, $email, $pwd)
        {
            $result = $conn->query("UPDATE $table SET fname ='$fname', lname='$lname', mobile='$mobile', dob='$dob', uname='$uname', email='$email', pwd='$pwd' WHERE id='$id'");
            return $result;       
        }

        function Check_utility($conn, $table, $id)
        {
            $result = $conn->query("SELECT * FROM ". $table." WHERE id='". $id."'");
            return $result;          
        }

        function Delete($conn,$table,$id)
        {
            $result = $conn->query("DELETE FROM ". $table." WHERE id='". $id."'");
            return $result;
        }

        function CloseCon($conn)
        {
            $conn->close();
        }
    }
?>