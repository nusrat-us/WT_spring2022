<?php
    require("../model/db.php");
    $msg="";

    if(isset($_POST["submit"]))
    {
        $connection = new db();

        $conobj=$connection->Opencon();

        $userQuery=$connection->Insert_ah($conobj,"account_holder",$_SESSION["fname"],$_SESSION["lname"],$_SESSION["dob"],$_SESSION["uname"],$_SESSION["email"],$_SESSION["pwd"],$_SESSION["account"]);

        if($conobj->query($userQuery) != TRUE)
        {
            $msg = "Registered Successfully";
            header("Location: ../view/ah_login.php");

        }
        else
        {
            $msg = "Error: " . $userQuery . "<br>" . $conobj->error;
        }

        $connection->Closecon($conobj);
    }
    
?>
