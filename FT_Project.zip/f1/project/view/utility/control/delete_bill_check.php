<?php
    $id=$msg=$uname=$amount=$bill="";
    
    if(isset($_POST["enter"]))
    {
        $connection = new db();
        $conobj=$connection->OpenCon();
        $userQuery=$connection->Check_utility($conobj,"bill",$_POST["id"]);
        
        
        if($userQuery !== false && $userQuery->num_rows > 0) 
        {
            while($row = $userQuery->fetch_assoc()) 
            {
                $id = $row["id"];
                $uname = $row["uname1"];
                $amount = $row["amount"];
                $bill = $row["bill"];
            }
        } 
        else 
        {
            $msg1 = "0 results";
        }
    }

    if(isset($_POST["delete"]))
    {
        $id = $_POST["id1"];
        $uname = $_POST["uname"];
        $amount = $_POST["amount"];
        $bill = $_POST["bill"];


        $connection = new db();
        $conobj=$connection->OpenCon();
        $userQuery=$connection->Delete($conobj,"bill", $id);

        if($conobj->query($userQuery) != TRUE) 
        {
            $msg = "Deleted successfully!";
            $id = "";
            $uname = "";
            $amount = "";
            $bill = "";
        }
        else 
        {
            $msg = "Delete Failed!";
        }
     
    }
?>