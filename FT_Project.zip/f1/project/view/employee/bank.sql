-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3307
-- Generation Time: Dec 18, 2021 at 04:44 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bank`
--

-- --------------------------------------------------------

--
-- Table structure for table `account_holder`
--

CREATE TABLE `account_holder` (
  `fname` text NOT NULL,
  `lname` text NOT NULL,
  `age` int(100) NOT NULL,
  `uname` text NOT NULL,
  `uid` text NOT NULL,
  `email` varchar(100) NOT NULL,
  `pwd` varchar(100) NOT NULL,
  `account` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `account_holder`
--

INSERT INTO `account_holder` (`fname`, `lname`, `age`, `uname`, `uid`, `email`, `pwd`, `account`) VALUES
('', '', 0, '', '', '', '', ''),
('Akif', 'Zaman', 23, 'akif123', '34', 'akifzaman101@yahoo.com', 'akif@1234', 'Normal Account'),
('jahan', 'jahan', 23, 'jahan12', '5645', 'jahan@gmail.com', '3456', 'Saving Account'),
('tania', 'karim', 20, 'tania12', '45', 'tania12@gmail.com', '123', 'Checking Account'),
('zinia', 'tasnim', 20, 'zinia', '566', 'zinia67@gmail.com', '234', 'Saving Account');

-- --------------------------------------------------------

--
-- Table structure for table `account_info`
--

CREATE TABLE `account_info` (
  `username` text NOT NULL,
  `bank_account_no` int(11) NOT NULL,
  `curr_balance` text NOT NULL,
  `account_type` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `account_info`
--

INSERT INTO `account_info` (`username`, `bank_account_no`, `curr_balance`, `account_type`) VALUES
('jahan', 3456, '45678', 'Saving Account'),
('jahan', 345667, '4567856', 'Saving Account'),
('jahan', 3456, '45678', 'Saving Account'),
('tania', 34566789, '45678', 'Saving Account');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `fname` text NOT NULL,
  `lname` text NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `dob` varchar(100) NOT NULL,
  `uname` text NOT NULL,
  `email` varchar(100) NOT NULL,
  `pwd` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`fname`, `lname`, `mobile`, `dob`, `uname`, `email`, `pwd`) VALUES
('Akif', 'Zaman', '01758647896', '2021-10-18', 'akif123', 'akifzaman101@yahoo.com', 'akif@1234');

-- --------------------------------------------------------

--
-- Table structure for table `bank_loan`
--

CREATE TABLE `bank_loan` (
  `loan_assigned_to` text NOT NULL,
  `loan_amount` text NOT NULL,
  `interest_rate` text NOT NULL,
  `loan_period` text NOT NULL,
  `monthly_pay` text NOT NULL,
  `amount_paid` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bank_loan`
--

INSERT INTO `bank_loan` (`loan_assigned_to`, `loan_amount`, `interest_rate`, `loan_period`, `monthly_pay`, `amount_paid`) VALUES
('saif_ahmed', '10000 taka', '5%', '11 months', '500 taka', '3000 taka'),
('sara tasnim', '20000 taka', '6%', '2 years', '1000 taka', '4000 taka');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `fname` text NOT NULL,
  `lname` text NOT NULL,
  `gender` varchar(100) NOT NULL,
  `dob` varchar(100) NOT NULL,
  `mobile` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `jobpos` varchar(100) NOT NULL,
  `uname` varchar(100) NOT NULL,
  `pwd` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`fname`, `lname`, `gender`, `dob`, `mobile`, `email`, `jobpos`, `uname`, `pwd`) VALUES
('Fatima', 'Jahan', 'Female', '2021-12-29', 1771728241, 'abc@gmail.com', 'Accountant', 'abc12', '234'),
('Fatima', 'Jahan', 'Female', '2021-12-16', 1771728241, 'jui1245@gmail.com', 'Manager', 'jahan', '789'),
('dfg', 'rrrr', 'Female', '2021-12-15', 1771728241, 'jui@gmail.com', 'Accountant', 'jui', '1234'),
('sarah', 'sabin', 'Female', '2021-12-16', 1771728241, 'sara12@gmail.com', 'Accountant', 'sara', '123');

-- --------------------------------------------------------

--
-- Table structure for table `loan`
--

CREATE TABLE `loan` (
  `loan_amount` text NOT NULL,
  `interest_rate` text NOT NULL,
  `loan_period` text NOT NULL,
  `monthly_pay` text NOT NULL,
  `amount_paid` text NOT NULL,
  `remaining_amount` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `loan`
--

INSERT INTO `loan` (`loan_amount`, `interest_rate`, `loan_period`, `monthly_pay`, `amount_paid`, `remaining_amount`) VALUES
('[value-2]', '[value-3]', '[value-4]', '[value-5]', '[value-6]', '[value-7]'),
('[value-2]', '[value-3]', '[value-4]', '[value-5]', '[value-6]', '[value-7]');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `uname1` text NOT NULL,
  `amount` int(100) NOT NULL,
  `uname2` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`uname1`, `amount`, `uname2`) VALUES
('akif123', 500, 'mohsina123'),
('sara123', 1000, 'zinia');

-- --------------------------------------------------------

--
-- Table structure for table `utility`
--

CREATE TABLE `utility` (
  `fname` text NOT NULL,
  `lname` text NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `dob` varchar(100) NOT NULL,
  `uname` text NOT NULL,
  `email` varchar(100) NOT NULL,
  `pwd` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account_holder`
--
ALTER TABLE `account_holder`
  ADD PRIMARY KEY (`uname`(100)),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`uname`(100)),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`uname`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `utility`
--
ALTER TABLE `utility`
  ADD PRIMARY KEY (`uname`(100)),
  ADD UNIQUE KEY `email` (`email`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
