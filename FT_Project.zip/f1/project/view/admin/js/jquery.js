$(document).ready(function(){
    $("input").focus(function(){
      $(this).css("background-color", "SkyBlue");
    });
    $("input").blur(function(){
        $(this).css("background-color", "White");
    });
  });