<?php
    session_start();
    include("../control/ah_reg3_check.php");
?>
<html>
    <head> 
        <link rel="stylesheet" type="text/css" href="../CSS/style1.css">
        <h2>Account Holder Registration 3</h2>
        <hr>
    </head>

    <body>
        <div class ="ah_login_reg">
            <form method="POST">
                Your First name is "<?php echo $_SESSION["fname"] ?>"<br>
                Your Last name is "<?php echo $_SESSION["lname"] ?>"<br>
                Your Date of Birth is "<?php echo $_SESSION["dob"] ?>"<br>
                Your Username is "<?php echo $_SESSION["uname"] ?>"<br>
                Your Email is "<?php echo $_SESSION["email"] ?>"<br>
                Your Password is "<?php echo $_SESSION["pwd"] ?>"<br>
                Your Account-type is "<?php echo $_SESSION["account"] ?>"<br><br>
                <a href="ah_reg2.php">Back</a>
                <input type="submit" name="submit" value="Register">
            </form>
            <?php echo $msg ?>
        </div>
    </body>
</html>