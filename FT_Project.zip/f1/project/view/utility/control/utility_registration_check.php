<?php

    $validatefname = "";
    $validatelname = "";
    $validatemobile = "";
    $validatedate = "";
    $validateuname = "";
    $validateemail = "";
    $validatepwd = "";

    if(isset($_POST['next1']))
    {
        $_SESSION['fname'] = $_REQUEST['fname'];
        $_SESSION['lname'] = $_REQUEST['lname'];
        $_SESSION['mobile'] = $_REQUEST['mobile'];
        $_SESSION['dob'] = $_REQUEST['dob'];
        $_SESSION['uname'] = $_REQUEST['uname'];
        $_SESSION['email'] = $_REQUEST['email'];
        $_SESSION['pwd'] = $_REQUEST['pwd'];

        if(empty($_SESSION['fname']))
        {
            $validatefname = "  Enter your First Name PLEASE!";
        } 
        else
        {
            $validatefname = "";
        }

        if(empty($_SESSION['lname']))
        {
            $validatelname = "  Enter your Last Name PLEASE!";
        } 
        else
        {
            $validatelname = "";
        }

        if(empty($_SESSION['mobile']))
        {
            $validatemobile = "  Enter your Mobile Number PLEASE!";
        }
        else
        {
            $validatemobile = "";
        }

        if(empty($_SESSION['dob']))
        {
            $validatedate = "  Enter your Date of Birth PLEASE!";
        } 
        else
        {
            $validatedate = "";
        }

        if(empty($_SESSION['uname']))
        {
            $validateuname = " -> Enter you username PLEASE!";
        }
        else
        {
            $validateuname = "";
        }

        if(empty($_SESSION['email']))
        {
            $validateemail = " -> Enter your email PLEASE!";
        }
        else if(!preg_match("/^([a-z0-9+-]+)(.[a-z0-9+_-]+)@([a-z0-9-]+.)+[a-z]{2,6}$/ix",$_SESSION['email']))
        {
            $validateemail = " -> INVALID email!";
        }
        else
        {
            $validateemail = "";
        }

        if(empty($_SESSION['pwd'])) 
        {
            $validatepwd = " -> Enter your password PLEASE!";
        } 
        else if(!preg_match("/(?=.[@#$%^&+=]).*$/", $_SESSION['pwd'])) 
        {
            $validatepwd = " -> Password must atleast contain 1 special character";
        } 
        else
        {
            $validatepwd = "";
        }

        if($validatefname == "" && $validatelname == ""  && $validatemobile == "" && $validatedate == "" && $validateuname == "" && $validateemail == ""  && $validatepwd == "")
        {
            $_SESSION['fname'] = $_REQUEST['fname'];
            $_SESSION['lname'] = $_REQUEST['lname'];
            $_SESSION['mobile'] = $_REQUEST['mobile'];
            $_SESSION['dob'] = $_REQUEST['dob'];
            $_SESSION['uname'] = $_REQUEST['uname'];
            $_SESSION['email'] = $_REQUEST['email'];
            $_SESSION['pwd'] = $_REQUEST['pwd'];
            
            header("location: ../view/utility_registration1.php");
        }               
    }
?>