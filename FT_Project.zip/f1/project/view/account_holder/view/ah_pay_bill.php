<?php
    session_start();
    include("../control/ah_pay_bill_check.php");

    if(empty($_SESSION["uname"]))
    {
        header("Location: ah_login.php");
    }
?>
<html>
    <head>
    <link rel="stylesheet" type="text/css" href="../CSS/style1.css">
        <h2>Pay Bill to Utility</h2>
    </head>
    <hr>
    <body>
    <div class ="ah_login_reg">
        <form method="POST">
            <table>
                <input type="hidden" name="uname1" id="uname1" value="<?php echo $_SESSION["uname"] ?>">
                <tr>
                    <td>Enter amount:</td>
                    <td><input type="text" id="amount" name="amount"></td>
                </tr>
                <input type="hidden" name="uname2" id="uname2" value="Utility">
                <tr>
                    <td>Enter Bill Type:</td>
                    <td>
                        <select name="bill" id="bill">
                            <option value="gas">Gas</option>
                            <option value="electricity">Electricity</option>
                            <option value="water">Water</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Enter Month:</td>
                    <td>
                        <select name="month" id="month">
                            <option value="january">January</option>
                            <option value="february">February</option>
                            <option value="march">March</option>
                            <option value="april">April</option>
                            <option value="may">May</option>
                            <option value="june">June</option>
                            <option value="july">July</option>
                            <option value="august">August</option>
                            <option value="september">September</option>
                            <option value="October">October</option>
                            <option value="november">Novenmber</option>
                            <option value="december">December</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td><input type ="submit" name="pay" value="Pay"></td>
                    <td><a href="ah_homepage.php">Back</a></td>
                </tr>
            </table>
        </form>
        <?php echo $msg ?>
</div>
    </body>
</html>