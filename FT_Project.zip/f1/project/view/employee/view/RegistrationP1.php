<?php
include('../control/RegistrationP1check.php');


if(isset($_SESSION['firstname']) && isset($_SESSION['lastname']) &&  isset($_SESSION['gender']) && isset($_SESSION['Dob']) && isset($_SESSION['mobile']) && isset($_SESSION['email']))
{
header("location: RegistrationP2.php");
}
?>

<!DOCTYPE html>
<html>



<body>
<title id="titlepage1" ></title>
       
<h1>Registration Form </h1>
<h2>Page 1: Personal Information </h2>  

<div class="RegistrationBox">
 
<form method="post" action="" onsubmit="return validateForm1()" >
    <table >
        <tr>
            <td>First Name:</td>
            <td><input type="text" name="fname" id="fname"> <?php echo $valFname; ?> </td> <td><p  id="errorfname"></p></td>
            
        </tr>

        <tr>
            <td>Last Name:</td>
            <td><input type="text" name="lname" id="lname"><?php echo $valLname; ?></td>  <td> <p  id="errorlname"></p></td>
        </tr>

        <tr>
            <td> Gender:</td>
            <td>
            <input type="radio" id="Male" name="gender" value="Male">
            <label for="Male">Male</label>

            <input type="radio" id="Female" name="gender" value="Female">
            <label for="Female">Female</label>

            <?php echo $valradioGender; ?>             
     
            </td> <td> <p  id="errorgender"></p></td>
        </tr>

        <tr>
            <td>Date of Birth:</td>
            <td><input type="date" name="dob" id="dob"><?php echo $valDob; ?></td> <td> <p  id="errordob"></p></td>
        </tr>

        <tr>
            <td>Mobile:</td>
            <td><input type="text" name="mobile" id="mobile"><?php echo $valMobile; ?></td> <td> <p id="errormobile"></p></td>
        </tr>

        <tr>
            <td><label for="email">E-mail:</label></td>
            <td><input type="text" name="email" id="email"><?php echo $valemail; ?></td> <td> <p id="erroremail"></p></td>
        </tr>


        <tr>
            <td><label for="file"> Please choose a profile Picture</label></td>
            <td><input type="file" name="filetoupload"></td>
        </tr>



        <tr>
            <td><input type="submit" class="continue" name="continue" value="Continue"></td> <td><p id="demo1"></p></td>
        </tr>

    </table>
    <br> <br>
    
    
<a  href="../control/logout.php">Cancel</a> <p id="demo2"></p>
</form>
</div>
<script src="..\JS\jquery.min.js">  </script>
<script src="..\JS\jqueryform1.js">  </script>
<script src="..\JS\myjs.js">  </script>
</body>
</html>




