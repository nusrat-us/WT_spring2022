

<!DOCTYPE html>
<html>
<body>


<h2> Registation Successfull !</h2>


<h5>Go To <a href="../control/logout.php">Home page</a></h5>
<script src="..\JS\jqueryform1.js">  </script>
<script src="..\JS\myjs.js">  </script>


</body>
</html>