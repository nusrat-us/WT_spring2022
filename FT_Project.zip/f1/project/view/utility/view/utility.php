<?php
    session_start();
    if(empty($_SESSION['uname']))
    {
        header("location: ../project/utility_login.php");
    }

    require("../model/db.php");

    $connection = new db();
    $conobj=$connection->OpenCon();
    $uname = $_SESSION["uname"];
    $userQuery=$connection->ViewProfile($conobj,"utility",$uname);
    
    if($userQuery !== false && $userQuery->num_rows > 0) 
    {
        while($row = $userQuery->fetch_assoc()) 
        {
            $_SESSION["id"]=$row["id"];
            $_SESSION["fname"]=$row["fname"];
            $_SESSION["lname"]=$row["lname"];
            $_SESSION["mobile"]=$row["mobile"];
            $_SESSION["dob"]=$row["dob"];
            $_SESSION["uname"]=$row["uname"];
            $_SESSION["email"]=$row["email"];
            $_SESSION["pwd"]=$row["pwd"];
        }     
    } 
    else 
    {
        echo "0 results";
    }
?>

<html>
    <head>
    <link rel="stylesheet" href="../css/style.css">
        <h1>Welcome to Utility page</h1>
        <hr>
    </head>
    <body>
        <div class="navbar">
            <a href = "../view/utility_profile.php">view profile</a>
            <div class="dropdown">
                <button class="dropbtn">Acc Holders
                </button>
                <div class="dropdown-content">
                    <a href = "../view/utility_ah.php">View Acc Holders</a>
                    <a href = "../view/utility_ah_search.php">Search Acc Holder</a>
                </div>
            </div>
            <div class="dropdown">
                <button class="dropbtn">Bill
                </button>
                <div class="dropdown-content">
                    <a href = "../view/utility_bill.php">Assign Bill</a>
                    <a href = "../view/delete_bill.php">Delete Bill</a>
                </div>
            </div>
            <a href = "../control/logout.php">logout</a>
        </div>
        
        <form action="../control/utility_ads.php" method="POST">
            <table>
                <tr>
                    <td><label for = "ads" >ads:</td>
                    <td><textarea id = "ads" name = "ads" rows = "4" cols = "50" ></textarea></td>
                </tr>
                <tr>
                    <td><input type = "submit" name = "submit" value = "Enter"></td>
                </tr>
            </table>
        </form>

    </body>
</html>