<?php
session_start(); 
if(empty($_SESSION["username"]) && empty($_SESSION["password"]) ) 
{
header("Location: ../view/HomePage.php"); 
}

?>


<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="../CSS/accountant.css">
</head>
<body>

<div class="header">

<h1> Accountant Page </h1>

<h3>Welcome <?php echo $_SESSION["username"];?></h3>
</div>
<div class="sticky">
<div class="topnav">
<a href="#">Home</a>
<a href="../view/AccountHolderPageA.php">Account Holder</a>

<a href="../view/AccountInfoA.php">Manage Account Information</a>


<a href="../view/viewAdminProfileA.php">View Admin Profile</a>

<a href="../view/ViewTransaction.php">Transaction History</a>


  

<div class="dropdown">
<button class="dropbtn">Your Profile</button>
  <div class="dropdown-content">
  <a href="../view/ShowProfileA.php">View Profile</a>
  <br>
  <a href="../view/editProfileA.php">Edit Profile</a>

  
  </div>
</div>

</div>


</div>

<footer>

<a class="one" href="../control/logout.php">Logout</a>

</footer>


</body>
</html>