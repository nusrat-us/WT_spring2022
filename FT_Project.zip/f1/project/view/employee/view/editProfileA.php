<?php
session_start(); 

include('../control/editProfileCheck.php');


if(empty($_SESSION["username"])) 
{
header("Location: ../view/login.php");
}

?>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="../CSS/updateaccholder.css">
</head>
<body>
<div class="header">
<h2>Edit Profile Information</h2>
</div>
<br><br>
<br><br>
<br><br>

<div class="middlecolumn">
<form action='' method='post'>
<label>First Name :</label> <input type='text' name='fname' value="<?php echo $fname; ?>" >
<br><br>
<label>Last Name :</label> <input type='text' name='lname' value="<?php echo $lname; ?>" >
<br><br>
<label>Gender:</label>
 <?php echo $radioValidation; ?>
     <input type='radio' name='gender' value='Male'<?php echo $radio1; ?>>Male
     <input type='radio' name='gender' value='Female' <?php echo $radio2; ?> >Female    
<br>

<label>DOB :<label> <input type='date' name='dob' value="<?php echo $dob; ?>" ><br><br>
<label>E-mail : </label><input type='email' name='email' value="<?php echo $email; ?>" > <br><br>


<input type='submit' name='update' value='Confirm Edit'> 
</form>
<br><br>
<?php echo $message;?>
</div>
<br>


<footer>

<a class="two" href="../view/AccountantPage.php">Previous Page</a>

<a class="one" href="../control/logout.php">Logout</a>
</footer>



</body>
</html>

