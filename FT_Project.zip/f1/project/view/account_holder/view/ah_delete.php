<?php
    session_start();
    include("../control/ah_delete_check.php");
?>
<html>
    <head>
    <link rel="stylesheet" type="text/css" href="../CSS/style1.css">
    </head>
    <body>
        <form method="POST">
            <input type="hidden" id="uname" name="uname" value="<?php echo $_SESSION["uname"] ?>">

            Are you sure You want to Permanently DELETE you Account?
            <br><br><br>
            <input type ="submit" name="delete" value="Yes!">
            <a href="ah_homepage.php">No</a>
        </form>
    </body>
</html>