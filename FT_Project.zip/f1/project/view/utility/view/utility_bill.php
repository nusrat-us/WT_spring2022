<?php
    session_start();
    include("../control/utility_bill_check.php");
    if(empty($_SESSION['uname']))
    {
        header("location: ../project/utility_login.php");
    }
?>
<html>
    <head>
        <link rel="stylesheet" href="../css/style.css">
        <h1>Assign Bill</h1> 
        <hr>
    </head>
    <body>
    <form action="" method="POST">
        <table>
            <tr>
                <td><label for="uname1">UserName of the account:</label></td>                       
                <td><input type="text" id="uname1" name="uname1"></td>
                                                      
            </tr>
            <tr>
                <td><label for="amount">Last Name:</label></td>                       
                <td><input type="text" id="amount" name="amount" ></td>                                     
            </tr>

            <tr>
                <td><label for="bill">Bill:</label></td>                       
                <td>
                    <input type="radio" id="electricity" name="r1" value="electricity">
                    <label for="electricity">Electricity</label>
                    <input type="radio" id="Water" name="r1" value="Water">
                    <label for="Water">Water</label>
                    <input type="radio" id="pl" name="r1" value="Gas">
                    <label for="Gas">Gas</label>
                </td>
            </tr>
            <tr>
                <td><input type="submit" value="Submit" name = "submit"></td>
                <td><a href="utility.php">Back</a></td>
            </tr>
        </form>  
        <?php echo $msg ?>         
    </body>
</html>