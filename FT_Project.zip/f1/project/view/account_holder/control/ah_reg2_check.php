<?php
    $validateuname="";
    $validateemail="";
    $validatepwd="";
    $validateaccount="";
    $account;
    
    if(isset($_POST["submit"]))
    {
        $_SESSION["uname"]=$_POST["uname"];
        $_SESSION["email"]=$_POST["email"];
        $_SESSION["pwd"]=$_POST["pwd"];

        if(empty($_SESSION["uname"]))
        {
            $validateuname="Enter your username  please!";
        }
        else
        {
            $validateuname="";
        }

        if(empty($_SESSION["email"]))
        {
            $validateemail="Enter your email please!";
        }
        else if(!preg_match("/^([a-z0-9+-]+)(.[a-z0-9+_-]+)@([a-z0-9-]+.)+[a-z]{2,6}$/ix",$_SESSION['email']))
        {
            $validateemail = "INVALID email format!";
        }
        else
        {
            $validateemail="";
        }


        if(empty($_SESSION["pwd"]))
        {
            $validatepwd="Enter your password please!";
        }
        else
        {
            $validatepwd="";
        }

        if(!isset($_POST["account"]))
        {
            $validateaccount="Enter your account please!";
        }
        else
        {
            $account = $_REQUEST["account"];
            $validateaccount="";
        }
        


        if($validateuname =="" && $validateemail =="" && $validatepwd =="" && $validateaccount =="")
        {
            $_SESSION["account"]=$account;
            header("location: ../view/ah_reg3.php");
        }
    }
?>
