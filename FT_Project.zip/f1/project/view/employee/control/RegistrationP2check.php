<?php

session_start(); 

$Cemployed="";
$valRadioCemployed="";
$Jobexp="";
$valRadioJobexp="";


 if (isset($_POST['continue'])) 
{
    //$Cemployed= $_POST['curremp'];
    //$Jobexp=$_POST['jobexp'];

    
    if(isset($_POST['curremp']))
    {
        $_SESSION["Cemployed"]=$_POST['curremp'];
    
    }

    else
    {
        $valRadioCemployed="Please select yes/No";

    }


 
    if(isset($_POST['jobexp']))
    {
        $_SESSION["Jobexp"]=$_POST['jobexp'];
    
    }

    else
    {
        $valRadioJobexp="Please select yes/No";

    }
    
}

?>