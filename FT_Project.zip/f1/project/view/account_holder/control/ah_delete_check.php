<?php
    include("../model/db.php");

    

    if(isset($_POST["delete"]))
    {
        $connection = new db();
        $conobj=$connection->OpenCon();
        $user=$_POST["uname"];
        $MyQuery=$connection->Delete($conobj,"account_holder",$user);

        if($conobj->query($MyQuery) != TRUE)
        {
            echo "Deleted Successfully!";

            session_destroy();
            header("Location: ../view/ah_login.php");
        }
        else
        {
            echo "Delete Failed!";
        }
    }        

?>