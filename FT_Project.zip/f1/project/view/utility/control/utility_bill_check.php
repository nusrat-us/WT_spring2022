<?php

    $validateuname1="";
    $validateamount="";
    $validateradio="";
    $msg = "";
    if(isset($_POST['submit']))
    {    
        if($_SERVER["REQUEST_METHOD"]=="POST")
        {
            $_SESSION['uname1'] = $_REQUEST['uname1'];
            $_SESSION['amount'] = $_REQUEST['amount'];
            $_SESSION['r1'] = $_REQUEST['r1'];

    
            if(empty($_SESSION['uname1']))
            {
                $validateuname1 = " -> Enter your UserName PLEASE!";
                
            }
            else
            {
                $validateuname1 = "";
                
            }

            if(empty($_SESSION['amount']))
            {
                $validateamount = " -> Enter your amount PLEASE!";
                
            }
            else
            {
                $validateamount = "";
                
            }

            if(empty($_SESSION['r1']))
            {
                $validateradio = " -> Select a bill type PLEASE!";
            }
            else
            {
                $validateradio = "";
            }   
        }
        if($validateuname1 == "" && $validateamount == "" && $validateradio == "")
        {
            $msg="";
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "bank";

            $conn = new mysqli($servername, $username, $password, $dbname);

            if($conn->connect_error)
            {
                die("connection failed: " . $conn->connect_error);
            }

            $uname1 = $_SESSION['uname1'];
            $amount = $_SESSION['amount'];
            $bill = $_SESSION['r1'];

             
            $sql = "INSERT INTO bill(uname1,amount,bill) VALUES('$uname1','$amount','$bill')";

            if($conn->query($sql) == TRUE)
            {
                $msg = " Bill requested";
            }
            else
            {
                $msg ="Error: " . $sql . "<br>" . $conn->error;
            }    
            $conn->close();
        }        
    }
?>