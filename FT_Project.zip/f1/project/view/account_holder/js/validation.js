function ah_login_check()
{
    var uname = document.getElementById("uname").value;
    var pwd = document.getElementById("pwd").value;

    if(uname =="")
    {
        document.getElementById("err1").innerHTML =" Enter you username PLEASE!";
        return false;
    }
    if(uname.length<3)
    {
        document.getElementById("err1").innerHTML =" UserName cannot be less than 3 characters!";
        return false;
    }

    if(pwd =="")
    {
        document.getElementById("err1").innerHTML =" Enter you Password PLEASE!";
        return false;
    }
    if(pwd.length<3)
    {
        document.getElementById("err1").innerHTML =" Password length must be atleast 4";
        return false;
    }
}

function ah_reg1_check()
{
    var fname = document.getElementById("fname").value;
    var lname = document.getElementById("lname").value;
    var dob= document.getElementById("dob").value;

    if(fname =="")
    {
        document.getElementById("err2").innerHTML =" Enter you firstname PLEASE!";
        return false;
    }
    if(fname.length<3)
    {
        document.getElementById("err2").innerHTML =" First Name cannot be less than 3 characters";
        return false;
    }
    if(lname =="")
    {
        document.getElementById("err2").innerHTML =" Enter you lastname PLEASE!";
        return false;
    }  
    if(lname.length<3)
    {
        document.getElementById("err2").innerHTML =" Last Name cannot be less than 3 characters!";
        return false;
    }  
    if(dob =="")
    {
        document.getElementById("err2").innerHTML =" Enter you date of birth PLEASE!";
        return false;
    }  
}


function ah_reg2_check()
{
    var uname= document.getElementById("uname").value;
    var email= document.getElementById("email").value;
    var pwd = document.getElementById("pwd").value;
    var account= document.getElementById("account").value;
    var patt = /^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/;
    var res = patt.test(email);

    if(uname =="")
    {
        document.getElementById("err3").innerHTML =" Enter you username PLEASE!";
        return false;
    }
    if(uname.length<3)
    {
        document.getElementById("err3").innerHTML =" UserName Must be more than 3 characters";
        return false;
    }
    if(email =="")
    {
        document.getElementById("err3").innerHTML =" Enter you email PLEASE!";
        return false;
    }  
    if(!res)
    {
        document.getElementById("erremail").innerHTML = "Email format is not correct";
        return false;
    }
    if(pwd=="")
    {
        document.getElementById("err3").innerHTML =" Enter you password PLEASE!";
        return false;
    }
    if(pwd.length<3)
    {
        document.getElementById("err3").innerHTML =" Password must be atleast more than 3 characters!";
        return false;
    }
    
    if(account=="")
    {
        document.getElementById("err3").innerHTML =" Enter you account PLEASE!";
        return false;
    }  
}

function showmyuser() {
    var uname=  document.getElementById("ah").value;
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
  
      if (this.readyState == 4 && this.status == 200) {
        document.getElementById("srch").innerHTML = this.responseText;
      }
      else
      {
           document.getElementById("srch").innerHTML = this.status;
      }
    };
    xhttp.open("POST", "../control/ah_search_ah_check.php", true);
    xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhttp.send("uname="+uname);
}

function money_history() {
    var uname=  document.getElementById("history").value;
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
  
      if (this.readyState == 4 && this.status == 200) {
        document.getElementById("text").innerHTML = this.responseText;
      }
      else
      {
           document.getElementById("text").innerHTML = this.status;
      }
    };
    xhttp.open("POST", "../control/show_history.php", true);
    xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhttp.send("uname="+uname);
}


