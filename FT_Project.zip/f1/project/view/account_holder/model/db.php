<?php
    class db
    {
        function OpenCon()
        {
            $dbhost = "localhost";
            $dbuser = "root";
            $dbpass = "";
            $db = "bank";

            $conn = new mysqli($dbhost, $dbuser, $dbpass, $db);

            if($conn->connect_error)
            {
                die("connection failed: " . $conn->connect_error);
            }

          return $conn;

        }

        function Insert_ah($conn,$table,$fname,$lname,$dob,$uname,$email,$pwd,$account)
        {
            $result=$conn-> query("INSERT INTO $table(fname,lname,dob,uname,email,pwd,account) VALUES('$fname','$lname','$dob','$uname','$email','$pwd','$account')");
            return $result;
        }

        function Check_ah($conn, $table, $uname, $pwd)
        {
            $result = $conn->query("SELECT * FROM ". $table." WHERE uname='". $uname."' AND pwd='". $pwd."'");
            return $result;
        }

        function Check_ah2($conn, $table, $uname)
        {
            $result = $conn->query("SELECT * FROM ". $table." WHERE uname='". $uname."'");
            return $result;
        }

        function Update_ah($conn, $table, $id, $fname, $lname, $dob, $uname, $email, $pwd, $account)
        {
            $result = $conn->query("UPDATE $table SET fname ='$fname', lname='$lname', dob='$dob', uname='$uname', email='$email', pwd='$pwd', account='$account' WHERE id=$id");
            return $result;
            
        }

        function Delete($conn, $table, $uname)
        {
            $result = $conn->query("DELETE FROM ". $table." WHERE uname='". $uname."'");
            return $result;
        }

        function bill_pay($conn, $table, $uname, $amount, $bill, $month)
        {
            $result=$conn-> query("INSERT INTO $table(uname,amount,bill,month) VALUES('$uname','$amount','$bill','$month')");
            return $result;
        }

        function Closecon($conn)
        {
            $conn->close();
        }
        

    }
?>