<?php

include('../model/db.php');
 

$message="";
$Uname=$AccNo=$CurrBalance="";


if (isset($_POST['add'])) 
{
    $Uname=$_POST['uname'];
    $AccNo=$_POST['accNo'];
    $CurrBalance=$_POST['currbalance'];

         $connection = new db();
        $conobj=$connection->OpenCon();
    
        $userQuery=$connection->InsertAccountInfo($conobj,"account_info",$Uname,$AccNo,$CurrBalance,$_POST['acctype']);

        if ($userQuery==TRUE)
         {
 
            $message= "Added Successfuly ! ";
            
           }

          
         
        $connection->CloseCon($conobj);
    
}


?>