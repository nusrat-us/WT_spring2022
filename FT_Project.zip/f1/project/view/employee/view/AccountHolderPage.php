<?php

session_start(); 
if(empty($_SESSION["username"]) && empty($_SESSION["password"]) ) 
{
header("Location: ../view/HomePage.php"); 
}

?>


<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="../CSS/accholder.css">
</head>
<div class="header">
<h1>Manage Account Holder </h1>
<?php echo $_SESSION["username"];?>
</div>
<body>

<div class="sidenav">
    <br><br>
    <br><br>
    <br><br>
  <a href="../view/AccountHolderListM.php">View Account Holder List</a>
  <br><br>
  <a href="../view/searchAccountHolderM.php">Search Account Holder</a>
  <br><br>
  <a href="../view/addAccountHolder.php">Add Account Holder</a>
  <br><br>
  <a href="../view/updateAccountHolderM.php">Update Account Holder</a>
  <br><br>
  <a href="../view/removeAccHolder.php">Remove Account Holder</a>
  
</div>

<footer>

<a class="two" href="../view/ManagerPage.php">Previous Page</a>

<a class="one" href="../control/logout.php">Logout</a>
</footer>




</body>
</html>

