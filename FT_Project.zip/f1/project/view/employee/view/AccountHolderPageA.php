<?php

session_start(); 
if(empty($_SESSION["username"]) && empty($_SESSION["password"]) ) 
{
header("Location: ../view/HomePage.php"); 
}

?>


<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="../CSS/accholder.css">
</head>
<div class="header">
<h1>Account Holder Details</h1>




</div>
<body>

<div class="sidenav">
    <br><br>
    <br><br>
    <br><br>
  <a href="../view/AccountHolderListA.php">Account Holder List</a>
  <br><br>
  <a href="../view/searchAccountHolderA.php">Search Account Holder</a>
  
  
  
</div>

<footer>

<a class="two" href="../view/AccountantPage.php">Previous Page</a>

<a class="one" href="../control/logout.php">Logout</a>
</footer>




</body>
</html>

