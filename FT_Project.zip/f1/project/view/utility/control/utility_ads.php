<?php 

	$formdata = array(
        
	    'ads'=>$_POST["ads"]
    );
    $existingdata = file_get_contents('data.json');
    $tempJSONdata = json_decode($existingdata);
    $tempJSONdata[0] =$formdata;
	$jsondata = json_encode($tempJSONdata, JSON_PRETTY_PRINT);
	   
    if(isset($_POST["submit"]))
    {
        if(!empty($_POST["ads"]))
        {
            if(file_put_contents("data.json", $jsondata)) 
            {              
                echo  "Ads Displayed successfully saved <br>";
            }
            else
            {
               echo "no ads saved";
            }
        }
        else
        {
            echo "error1";
        }
    }
    else
    {
        echo "error2";
    }
?>