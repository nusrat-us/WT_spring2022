<html>
    <head>
    <link rel="stylesheet" type="text/css" href="../CSS/style1.css">
    </head>
    <body>
        <script src="../js/validation.js"></script>

        Search Account Holder: <input type="text" name="ah" id="ah" placeHolder="Search..."><br><br>
        <button onclick="showmyuser()">Search</button>
        <a href="ah_homepage.php"><button>Back</button></a>
        <br><br>
        <p id="srch"></p>
    </body>
</html>