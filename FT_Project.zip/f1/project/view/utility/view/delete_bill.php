<?php
    session_start();
    $msg1="";
    require("../model/db.php");
    include("../control/delete_bill_check.php");
?>
<html>
    <head>
        <link rel="stylesheet" href="../css/style.css">
        <h1>Account Holders</h1>
        <hr>        
    </head>
    <body>

        <br><br>
<div class="ah">
<?php    
    $connection = new db();
    $conobj = $connection->OpenCon();

    $userQuery = $connection->ShowAll($conobj,"bill");

    if($userQuery !== false && $userQuery->num_rows > 0)
    {     
        echo "<table><tr><th>ID</th><th>UserName</th><th>Amount</th><th>Bill</th></tr>";
        while($row = $userQuery->fetch_assoc())
        {
            echo "<tr><td>".$row["id"]."</td><td>".$row["uname1"]."</td><td>".$row["amount"]."</td><td>".$row["bill"]."</td></tr>";
        }
        echo "</table>";
    } 
    else 
    {
        echo "0 results";
    }
?>
<hr>
</div>   
        <br><br>
        
        <h2>Delete Bill</h2>
        
        <form method="POST">
            <input type="text" name= "id" id="id" placeholder="Enter ID"><br><br>
            <input type="submit" class="Enter" name="enter" value="Enter">
            <a href="utility.php">Back</a>
        </form>
        <?php echo $msg1 ?>
        <p id="err"></p>
        
        <form method="POST">
            <input type="hidden" name="id1" id="id1" value="<?php echo $id ?>"><br>
            <p class="text">UserName:</p><br>
            <input type="text" name="uname" id="uname" value="<?php echo $uname ?>"><br>
            <p class="text">Amount:</p><br>
            <input type="text" name="amount" id="amount" value="<?php echo $amount ?>"><br>
            <p class="text">Bill:</p><br>
            <input type="text" name="bill" id="bill" value="<?php echo $bill ?>"><br>       
            <input type="submit" class="delete" name="delete" value="Delete">
        </form>
       <p class="msg" ><?php echo $msg ?></p>       
    </body>
</html>