<?php
    session_start();
    require("../control/admin_registration2_check.php");
?>

<!DOCTYPE HTML>
    <html>
        <head>
            <link rel="stylesheet" href="../css/style.css"></link>
            <link rel="stylesheet" href="../css/style1.css"></link>
            <h1>Admin Registration Form</h1>
        </head>
        <hr>
        <body>
            <div class="login_reg">
                <form action="" method="POST">
                    <table>
                        <tr>
                            <td>Your First name is: </td>
                            <td><input type="text" value="<?php echo $_SESSION['fname'] ?>" readonly></td>
                        </tr> 
                        <tr>
                            <td>Your Last name is: </td>
                            <td><input type="text" value="<?php echo $_SESSION['lname'] ?>" readonly></td>
                        </tr>
                        <tr>
                            <td>Your mobile number is: </td>
                            <td><input type="text" value="<?php echo $_SESSION['mobile'] ?>" readonly></td>
                        </tr>
                        <tr>
                            <td>Your Date of Birth is: </td>
                            <td><input type="text" value="<?php echo $_SESSION['dob'] ?>" readonly></td>
                        </tr>         
                        <tr>
                            <td>Your Username is: </td>
                            <td><input type="text" value="<?php echo $_SESSION['uname'] ?>" readonly></td>
                        </tr>
                        <tr>
                            <td>Your email is: </td>
                            <td><input type="text" value="<?php echo $_SESSION['email'] ?>" readonly></td>
                        </tr>
                        <tr>
                            <td>Your Password is: </td>
                            <td><input type="text" value="<?php echo $_SESSION['pwd'] ?>" readonly></td>
                        </tr>

                        <tr>
                            <td><input type="submit" class="login_reg_button" name = "back2" value="Back"></td>
                            <td><input type = "submit" class="login_reg_button" name = "register" value = "Register"></td>
                        </tr>
                    </table>
                </form>
                    <?php
                        echo $msg;
                    ?>
            </div>                 
        </body>
    </html>