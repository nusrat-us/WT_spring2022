<?php
include('../control/logincheck.php');

?>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="../CSS/mycss.css">
</head>
<body>



<h1>Login Page </h1>


<div class="middlecolumn">
<form action="" method="post"  >
<div class="LoginBox">

    <table >
    <br>

        <tr>
            <td><label>User Name:</label></td>
            <td><input type="text" name="uname" id="uname" ></td>
        </tr>

        <tr>
            <td> <label>Password:</label></td>
            <td><input type="password" name="pwd" id="pwd"></td>
                
        </tr>

        <tr>
            <td> <label>Remember Me</label></td>
            <td>
            <input type="checkbox" id="remember"> 
            </td>
        </tr>
             
        

    </div>

    </table>

    <br><br>

    <input type="submit" name="submit" id="submit" value="LOGIN">
    
    <br><br>

    <a class="one" href="../control/logout.php">Cancel</a>
    <br><br>

    

</form>
<?php echo $errormessage;?>
</div>
</body>
</html>
