<?php

session_start(); 
if(empty($_SESSION["username"]) && empty($_SESSION["password"]) ) 
{
header("Location: ../view/HomePage.php"); 
}

?>


<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="../CSS/accholder.css">
</head>
<div class="header">
<h1>Manage Accountant </h1>

<?php echo $_SESSION["username"];?>




</div>
<body>

<div class="sidenav">
    <br><br>
    <br><br>
    <br><br>
  
  
  <a href="../view/addAccountantM.php">Add Accountant</a>
  <br><br>
  <a href="../view/updateAccountantM.php">Update Accountant</a>

   
</div>

<footer>

<a class="two" href="../view/ManagerPage.php">Previous Page</a>

<a class="one" href="../control/logout.php">Logout</a>
</footer>




</body>
</html>
