<?php
include('../model/db.php');
session_start();

 
$connection = new db();
$conobj=$connection->OpenCon();
$userQuery=$connection->AccountHolderList($conobj,"account_holder");
$connection->CloseCon($conobj);


/*if($userQuery !== false && $userQuery->num_rows > 0 )
{

    //echo "<table><tr><th>fname</th><th>lname</th><th>age</th><th>email</th><th>account</th></tr>";

    while($row = $userQuery->fetch_assoc())
    {
        //echo "<tr><td>".$row["fname"]."</td><td>".$row["lname"]."</td><td>".$row["age"]."</td><td>".$row["email"]."</td><td>".$row["account"]."</td></tr>";
       // $fname=$row["fname"];
        //$lname=$row["lname"];
        //$age=$row["age"];
        //$email=$row["email"];
       // $account=$row["account"];
    }

    //echo "</table>";

  } 
else
{
    echo "0 results";
}*/

?>


