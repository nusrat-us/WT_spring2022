<?php
include('../model/db.php');
       
$radio1=$radio2=$valradiogender="";
$uname=$fname=$lname= $dob=$mobile=$email=$successmessage="";
 if(isset($_POST["search"]))
 {
     
$uname=$_POST["username"];
   
 $connection = new db();
 $conobj=$connection->OpenCon();
 
 $userQuery=$connection->searchAccountant($conobj,"employee",$uname);
 
 
 if ($userQuery !== false && $userQuery->num_rows > 0) {
 
     // output data of each row
     while($row = $userQuery->fetch_assoc())
      {
       $fname=$row["fname"];
       $lname=$row["lname"];

       if( $row["gender"]=="Male")
       {
           $radio1="checked";
       }
       else if($row["gender"]=="Female")
       {
           $radio2="checked";
       }
       else
       {
           $valradiogender="Nothing was checked !";
       }
       
       $dob=$row["dob"];
       $mobile=$row["mobile"];
       $email=$row["email"];
       
    
   } 
 }
   else {
     echo "0 results";
   }
}

 if(isset($_POST["update"]))
 {
       
       $uname=$_POST['username'];
       $fname=$_POST['fname'];
       $lname=$_POST['lname'];
       //$gender=$row["gender"];
       $dob=$_POST['dob'];
       $mobile=$_POST['mobile'];
       $email=$_POST['email'];

    $connection = new db();
    $conobj=$connection->OpenCon();
 
    $userQuery=$connection->UpdateAccountant($conobj,"employee",$uname,$fname,$lname,$_POST['gender'],$dob,$mobile,$email);
 
 
 if ($userQuery==TRUE) {
 
    $successmessage= "Update Successful ! ";
    
   } 
 
   else {

    $successmessage="Could not update !";
    
    
   }
   $connection->CloseCon($conobj);




 

 }


 

?>
