<?php
    session_start();
    include("../control/admin_check.php");
    
    if(empty($_SESSION['uname']))
    {
        header("location: ../project/admin_login.php");
    }
?>
<html>
    <link rel="stylesheet" href="../css/style.css">
    <head>
        
        <h1 class="admin_header">Admin HomePage of, <?php echo $_SESSION["fname"]." ".$_SESSION["lname"] ?></h1>
        <hr>
    </head>
    <body>

        <div class="navbar">
        <a href = "../view/admin_search.php">Search Profiles</a>
            <div class="dropdown">
                <button class="dropbtn">Update and Delete users
                </button>
                <div class="dropdown-content">
                <a href = "../view/admin_ah.php">Account Holders</a>
                <a href = "../view/admin_emp.php">Employees</a>
                <a href = "../view/admin_utility.php">Utility</a>
                </div>
            </div>
            <div class="dropdown">
                <button class="dropbtn">Account
                </button>
                <div class="dropdown-content">
                <a href = "../view/admin_profile.php">Profile</a>
                <a href = "../control/logout.php">Log out</a>
                </div>
            </div>
        </div>
        <br><br><br>
        <div class="form">
            <form action="../control/admin_notice.php" method="POST">
                <table>
                    <tr>
                        <td><label for = "notice" >Notice:</td>
                        <td><textarea id = "notice" name = "notice" rows = "4" cols = "50" ></textarea></td>
                    </tr>
                    <tr>
                        <td ><input type = "submit" id="submit" name = "submit" value = "Enter"></td>
                    </tr>
                </table>
            </form>
        </div>
        <br><br><br><br>
    </body>
</html>