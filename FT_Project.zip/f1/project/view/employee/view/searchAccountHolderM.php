
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="../CSS/searchaccholder.css">
</head>
<div class="header">
<h1> Find Account Holder</h1>
</div>

<body>

<br><br>
<br><br>
<br><br>

<div class="middlecolumn">
    
<table>
    <br>

        <tr>
   
            <td><label>Search by username:</label></td>
             <td><input type="text" name="username" id="username" placeholder="Search.."></td>
        
        </tr>

        <tr>
            
             <td><button class="box1 search" type="button" onclick="MyAjaxFunc()">Search</button></td>
        
        </tr> 


    </table>
    <h4 id="demo"></h4>
    <br>
    <br>
</div>

<footer>

<a class="two" href="../view/AccountHolderPage.php">Previous Page</a>

<a class="one" href="../control/logout.php">Logout</a>
</footer>

    <script src="../JS/myjs.js"></script>

    
</body>
</html>
