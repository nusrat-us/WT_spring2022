
<!DOCTYPE html>
<html>
<head>
        <link rel="stylesheet" type="text/css" href="../CSS/updateaccholder.css">
    </head>
<body>

<div class="header">
<h1> Bank Management System</h1>

<h2> Employee Home Page </h2>
</div>

<div class="links">




<h3> Create an account <a  href="../view/RegistrationP1.php">Registration</a><br></h3>

 <h3>Already have an account ? <a  href="../view/login.php">LOGIN</a><br></h3>

<h3>View Notice <a  href="../view/viewNotice.php">Notice</a><br></h3>

</div>


</body>
</html>



