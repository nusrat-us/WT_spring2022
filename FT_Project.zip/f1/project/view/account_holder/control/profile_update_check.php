<?php
    require("../model/db.php");
    
    $msg=$id=$fname=$lname=$dob=$uname=$email=$pwd=$account="";

    if(isset($_POST["update"]))
    {
        $id = $_POST["id"];
        $fname = $_POST["fname"];
        $lname = $_POST["lname"];
        $dob = $_POST["dob"];
        $uname = $_POST["uname"];
        $email = $_POST["email"];
        $pwd = $_POST["pwd"];
        $account = $_POST["account"];

        $connection = new db();
        $conobj=$connection->OpenCon();
        $userQuery=$connection->Update_ah($conobj, "account_holder", $id, $fname, $lname, $dob, $uname, $email, $pwd, $account);

        if($conobj->query($userQuery) == TRUE) 
        {
            $msg = "Update Failed!". $conobj->error;
            
        }
        else 
        {
            $msg = "Updated successfully!";

            $_SESSION["fname"]=$_POST["fname"];
            $_SESSION["lname"]=$_POST["lname"];
            $_SESSION["dob"]=$_POST["dob"];
            $_SESSION["uname"]=$_POST["uname"];
            $_SESSION["email"]=$_POST["email"];
            $_SESSION["pwd"]=$_POST["pwd"];
            $_SESSION["account"]=$_POST["account"];
        }
     
    }
    
 


?>