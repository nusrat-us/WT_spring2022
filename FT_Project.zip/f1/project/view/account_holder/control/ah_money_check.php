<?php

    $validateuname1="";
    $validateamount="";
    $msg = ""; 
    if($_SERVER["REQUEST_METHOD"]=="POST")
    {
        $_SESSION['uname1'] = $_REQUEST['uname1'];
        $_SESSION['amount'] = $_REQUEST['amount'];

        if(empty($_SESSION['uname1']))
        {
            $validateuname1 = " -> Enter your UserName PLEASE!";
                    
        }
        else
        {
            $validateuname1 = "";
                    
        }

        if(empty($_SESSION['amount']))
        {
            $validateamount = " -> Enter your amount PLEASE!";
                    
        }
        else
        {
            $validateamount = "";
                    
        }
            
        if($validateuname1 == "" && $validateamount == "")
        {
            if(isset($_POST['dep']))
            {
                $msg = "Deposite Completed";
            }
            else if(isset($_POST['wid']))
            {           
                $msg = "Withdraw Completed";
            }
            else
            {
                $msg = "Error";
            }                             
        }
    }
   
?>