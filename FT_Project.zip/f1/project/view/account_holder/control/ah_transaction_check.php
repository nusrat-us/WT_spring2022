<?php

    $validateuname1="";
    $validateamount="";
    $validateuname2="";
    $msg = "";
    if(isset($_POST['submit']))
    {     
        if($_SERVER["REQUEST_METHOD"]=="POST")
        {
            $_SESSION['uname1'] = $_REQUEST['uname1'];
            $_SESSION['amount'] = $_REQUEST['amount'];
            $_SESSION['uname2'] = $_REQUEST['uname2'];

    
            if(empty($_SESSION['uname1']))
            {
                $validateuname1 = " -> Enter your UserName PLEASE!";
                
            }
            else
            {
                $validateuname1 = "";
                
            }

            if(empty($_SESSION['amount']))
            {
                $validateamount = " -> Enter your amount PLEASE!";
                
            }
            else
            {
                $validateamount = "";
                
            }

            if(empty($_SESSION['uname2']))
            {
                $validateuname2 = " -> Enter Recievers UserName PLEASE!";
            }
            else
            {
                $validateuname2 = "";
            }   
        }
        if($validateuname1 == "" && $validateamount == "" && $validateuname2 == "")
        {
            $msg="";
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "bank";

            $conn = new mysqli($servername, $username, $password, $dbname);

            if($conn->connect_error)
            {
                die("connection failed: " . $conn->connect_error);
            }

            $uname1 = $_SESSION['uname1'];
            $amount = $_SESSION['amount'];
            $uname2 = $_SESSION['uname2'];

             
            $sql = "INSERT INTO transactions(uname1,amount,uname2) VALUES('$uname1','$amount','$uname2')";

            if($conn->query($sql) == TRUE)
            {
                $msg = " Tansaction Completed";
            }
            else
            {
                $msg ="Error: " . $sql . "<br>" . $conn->error;
            }    
            $conn->close();
        }        
    }
?>