<?php
    include("../model/db.php");

    $user = $_POST['uname'];

    if($user!="")
    {
        $data = file_get_contents("../json/data.json");
        $mydata = json_decode($data);
        foreach($mydata as $myobject)
        {
            foreach($myobject as $key=>$value)
            {
                echo $key.": ".$value."<br>";
            } 
                   
        } 
    }   
    else
    {
        echo "please enter something";
    }
?>