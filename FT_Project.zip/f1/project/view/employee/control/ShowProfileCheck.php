<?php
include('../model/db.php');
session_start(); 



$connection = new db();
$conobj=$connection->OpenCon();

$username=$_SESSION["username"];

$userQuery=$connection->myProfile($conobj,"employee",$username);
$connection->CloseCon($conobj);

/*if($userQuery !== false && $userQuery->num_rows > 0 )
  {
       <tr>
    <th>First Name</th>
    <th>Last Name </th>
    <th>Gender</th>
    <th>Date of Birth</th>
    <th>E-mail</th>
    <th>Job Position</th>
    
  </tr>

    while($row = $userQuery->fetch_assoc())
      {
        echo "firstname : <input type='text' name='fname' value=".$row["fname"]." > <br>";
        echo "First Name : ".$row["fname"]."<br>";
    
        echo "Last Name : ".$row["lname"]."<br>";

        echo "Gender : ".$row["gender"]."<br>";

        echo "Date of Birth : ".$row["dob"]."<br>";

        echo "E-mail : ".$row["email"]."<br>";
      
        echo "Job Position: ".$row["jobpos"]."<br>";
      }

  }

else
  {
    echo "0 results";
  }*/
  
?>


