<?php
    $msg=$fname=$lname=$age=$uname=$id=$email=$pwd=$account="";
    
    if(isset($_POST["enter"]))
    {
        $connection = new db();
        $conobj=$connection->OpenCon();
        $userQuery=$connection->Check_ah($conobj,"account_holder",$_POST["id"]);
        
        
        if($userQuery !== false && $userQuery->num_rows > 0) 
        {
            while($row = $userQuery->fetch_assoc()) 
            {
                $id = $row["id"];
                $fname = $row["fname"];
                $lname = $row["lname"];
                $age = $row["age"];
                $uname = $row["uname"];
                $email = $row["email"];
                $pwd = $row["pwd"];
                $account = $row["account"];
            }
        } 
        else 
        {
            $msg1 = "0 results";
        }
    }

    if(isset($_POST["update"]))
    {
        $id = $_POST["id1"];
        $fname = $_POST["fname"];
        $lname = $_POST["lname"];
        $age = $_POST["age"];
        $uname = $_POST["uname"];
        $email = $_POST["email"];
        $pwd = $_POST["pwd"];
        $account = $_POST["account"];

        $connection = new db();
        $conobj=$connection->OpenCon();
        $userQuery=$connection->Update_ah($conobj,"account_holder", $id, $fname, $lname, $age, $uname, $email, $pwd, $account);

        if($conobj->query($userQuery) != TRUE) 
        {
            $msg = "Updated successfully!";
        }
        else 
        {
            $msg = "Update Failed!";
        }
     
    }

    if(isset($_POST["delete"]))
    {
        $id = $_POST["id1"];
        $fname = $_POST["fname"];
        $lname = $_POST["lname"];
        $age = $_POST["age"];
        $uname = $_POST["uname"];
        $email = $_POST["email"];
        $pwd = $_POST["pwd"];
        $account = $_POST["account"];

        $connection = new db();
        $conobj=$connection->OpenCon();
        $userQuery=$connection->Delete($conobj,"account_holder", $uname);

        if($conobj->query($userQuery) != TRUE) 
        {
            $msg = "Deleted successfully!";
        }
        else 
        {
            $msg = "Delete Failed!";
        }
     
    }
?>