<?php
include('../model/db.php');


 $error="";
 $message="";

 $radio1=$radio2=$radio3=$radioValidation=$dob="";
 $fname=$lname=$email="";
 $connection = new db();
 $conobj=$connection->OpenCon();
 
 $userQuery=$connection->myProfile($conobj,"employee",$_SESSION["username"]);
 
 if ($userQuery !== false && $userQuery->num_rows > 0) {
 
     // output data of each row
     while($row = $userQuery->fetch_assoc()) 
     {
       $fname=$row["fname"];
       $lname=$row["lname"];
       
       if(  $row["gender"]=="Male" )
       { $radio1="checked"; }
       else if($row["gender"]=="Female")
       { $radio2="checked"; }
       
       else
       {
         $radioValidation="Nothing was checked";
       }
       $dob=$row["dob"];
       $email=$row["email"];
       
      
   } 
 }
   else {
     echo "0 results";
   }
 
 




if (isset($_POST['update'])) {
if (empty($_POST['fname']) || empty($_POST['email'])) {
$error = "input given is invalid";
}
else
{
$connection = new db();
$conobj=$connection->OpenCon();

$userQuery=$connection->UpdatemyProfile($conobj,"employee",$_SESSION["username"],$_POST['fname'],$_POST['lname'],$_POST['gender'],$_POST["dob"],$_POST['email']);
if($userQuery==TRUE)
{
    $message="Your profile information is Updated !";
}
else
{
    $message= "could not update";    
}
$connection->CloseCon($conobj);

}
}


?>
