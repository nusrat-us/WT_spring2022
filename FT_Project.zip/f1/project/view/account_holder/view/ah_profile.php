<?php
    session_start();
    
    include("../control/profile_update_check.php");

    if(empty($_SESSION["uname"]))
    {
        header("Location: ah_login.php");
    }

?>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="../CSS/style1.css">
        <h1><?php echo $_SESSION["fname"]." ". $_SESSION["lname"] ?>'s Profile</h1>
    </head>
    <body>
        <div class="form">
        <form method="POST">
        <div class ="ah_login_reg">
            <table>
                <tr>
                    <td><input type="hidden" name="id" id="id" value="<?php echo $_SESSION["id"] ?>"></td>
                </tr>
                <tr>
                    <td>First Name:</td>
                    <td><input type = "text" name="fname" id="fname" value="<?php echo $_SESSION["fname"] ?>" ></td>
                </tr>
                <tr>
                    <td>Last Name:</td>
                    <td><input type = "text" name="lname" id="lname" value="<?php echo $_SESSION["lname"] ?>"></td>
                </tr>
                <tr>
                    <td>Date of Birth:</td>
                    <td><input type = "date" name="dob" id="dob" value="<?php echo $_SESSION["dob"] ?>"></td>
                </tr>
                <tr>
                    <td>Usename:</td>
                    <td><input type = "text" name="uname" id="uname" value="<?php echo $_SESSION["uname"] ?>"></td>
                </tr>
                <tr>
                    <td>Email:</td>
                    <td><input type = "email" name="email" id="email" value="<?php echo $_SESSION["email"] ?>"></td>
                </tr>
                <tr>
                    <td>Password:</td>
                    <td><input type = "text" name="pwd" id="pwd" value="<?php echo $_SESSION["pwd"] ?>"></td>
                </tr>
                <tr>
                    <td>Account type:</td>
                    <td>
                        <?php
                                if($_SESSION["account"]=="Normal Account")
                                {
                        ?>
                                    <input type = "radio" name="account" id="account" value="Normal Account" checked>Normal Account
                                    <input type = "radio" name="account" id="account" value="Fixed Account">Fixed Account
                                    <input type = "radio" name="account" id="account" value="Savings Account">Savings Account
                        <?php
                                }
                                else if($_SESSION["account"]=="Fixed Account"){
                        ?> 
                                    <input type = "radio" name="account" id="account" value="Normal Account">Normal Account
                                    <input type = "radio" name="account" id="account" value="Fixed Account" checked>Fixed Account
                                    <input type = "radio" name="account" id="account" value="Savings Account">Savings Account
                        <?php
                                }
                                else if($_SESSION["account"]=="Savings Account")
                                {
                        ?>
                                    <input type = "radio" name="account" id="account" value="Normal Account">Normal Account
                                    <input type = "radio" name="account" id="account" value="Fixed Account">Fixed Account
                                    <input type = "radio" name="account" id="account" value="Savings Account" checked>Savings Account
                        <?php
                                }
                        ?>
                    </td>
                </tr>
                <tr>
                    <td><input type="submit" name="update" value="Update"></td>
                    <td><a href="ah_homepage.php">Back</a></td>
                    
                </tr>
            </table>     
        </form>
        <?php echo $msg ?>
        </div>
    </body>
</html>