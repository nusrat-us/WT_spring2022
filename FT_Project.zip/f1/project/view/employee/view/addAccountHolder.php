<?php
include('../control/addAccountHolderCheck.php');

/*if(isset($Fname) && isset($Lname) && isset($Age) && isset($Uname) && isset($Uid) && isset($Email) && isset($Password) && isset($AccType))
{
    $message= "Added Successfully !";
}*/
?>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="../CSS/updateaccholder.css">
</head>
<body>
<div class="header">
<h1>Add Account Holder</h1>
</div>

<br><br>
<br><br>
<br><br>

<div class="middlecolumn" >



<form action="" method="post" onsubmit="return AddAccHolderFormVal()">
    <table >
        <tr>
            <td><label>First Name:</label></td>
            <td><input type="text" name="fname" id="fname">  </td><td> </td> <td><p class="error" id="errorfname"></p></td>
        </tr>

        <tr>
            <td><label>Last Name:</label></td>
            <td><input type="text" name="lname" id="lname" ></td><td> </td> <td><p class="error" id="errorlname"></p></td>
        </tr>

        <tr>
            <td><label>Age:</label></td>
            <td><input type="number" name="age" id="age"></td><td></td>  <td><p class="error" id="errorage"></p></td>
        </tr>

    

        <tr>
            <td><label>User Name:</label></td>
            <td><input type="text" name="uname" id="uname" ></td><td> </td> <td><p class="error" id="erroruname"></p></td>
        </tr>


        <tr>
            <td><label>User Id:</label></td>
            <td><input type="text" name="uid" id="uid" ></td><td> </td> <td><p class="error" id="erroruid"></p></td>
        </tr>
        <tr>
            <td><label>E-mail:</label></td>
            <td><input type="email" name="email" id="email" ></td><td></td> <td><p class="error" id="erroremail"></p></td>  
        </tr>


        <tr>
            <td><label>Pasword:</label></td>
            <td><input type="password" name="pwd" id="pwd"></td><td> </td>  <td><p class="error" id="errorpwd"></p></td>
        </tr>
        <tr>
            <td><label> Account Type:</label></td>
            <td>
            <input type="radio" id="Normal Account" name="acctype" value="Normal Account">
            <label for="Normal Account">Normal Account</label>
            <br>

            <input type="radio" id="Saving Account" name="acctype" value="Saving Account">
            <label for="Saving Account">Saving Account</label>
            <br>
            <input type="radio" id="Checking Account" name="acctype" value="Checking Account">
            <label for="Checking Account">Checking Account</label>


                         
     
            </td> <td> <p class="error" id="erroracctype"></p></td>
        </tr>

    </table>
    <br>
        
    <input type="submit" class= "box1 add" name="add" value="Add">  

</form>

<br><br>
<?php

if(!empty($addSuccess))
{
    echo "<div class='box success'>".$addSuccess."</div>";
}

?>




</div>

<footer>

<a class="two" href="../view/AccountHolderPage.php">Previous Page</a>

<a class="one" href="../control/logout.php">Logout</a>
</footer>
<script src="../JS/myjs.js"></Script>
</body>
</html>