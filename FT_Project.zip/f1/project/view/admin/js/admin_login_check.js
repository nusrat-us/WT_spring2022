function admin_login_check()
{
    var uname = document.getElementById("uname").value;
    var pwd = document.getElementById("pwd").value;

    if(uname == "")
    {
        document.getElementById("error").innerHTML = "please insert username PLEASE!"
        return false;
    }

    if(uname.length<3)
    {
        document.getElementById("error").innerHTML = "UserName cannot be less than 3 characters!"
        return false;
    }
    
    if(pwd == "")
    {
        document.getElementById("error").innerHTML = "please insert password PLEASE!"
        return false;
    }

    if(pwd.length<5)
    {
        document.getElementById("error").innerHTML = "please insert password PLEASE!"
        return false;
    }
}

function admin_ah_check()
{
    var id=document.getElementById("id").value;

    if(id=="")
    {
        document.getElementById("err").innerHTML=" Enter Id Please!";
        return false;
    }
}

function admin_ah_check2()
{
    var fname = document.getElementById("fname").value;
    var lname = document.getElementById("lname").value;
    var age = document.getElementById("age").value;
    var uname = document.getElementById("uname").value;
    var email = document.getElementById("email").value;
    var pwd = document.getElementById("pwd").value;
    var account = document.getElementById("account").value;
    var patt = /^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/;
    var res = patt.test(email);

    if(fname=="")
    {
        document.getElementById("err1").innerHTML = " Enter First Name Please!";
        return false;
    }

    if(fname.length<2)
    {
        document.getElementById("err1").innerHTML = " First Name must be atleast more than 2 characters!";
        return false;
    }

    
    if(lname=="")
    {
        document.getElementById("err1").innerHTML = " Enter Last Name Please!";
        return false;
    }

    if(lname.length<2)
    {
        document.getElementById("err1").innerHTML = " Last Name must be atleast more than 2 characters!";
        return false;
    }

    
    if(age=="")
    {
        document.getElementById("err1").innerHTML = " Enter Age Please!";
        return false;
    }

    if(age<18)
    {
        document.getElementById("err1").innerHTML = " Age must be atleast 18 years Old!";
        return false;
    }

    
    if(uname=="")
    {
        document.getElementById("err1").innerHTML = " Enter Uname Please!";
        return false;
    }

    if(uname.length<3)
    {
        document.getElementById("err1").innerHTML = "Username must be more than 3 characters";
        return false;
    }

    
    if(email=="")
    {
        document.getElementById("err1").innerHTML = " Enter Email Please!";
        return false;
    }

    if(!res)
    {
        document.getElementById("error").innerHTML="Email format is not correct";
        return false; 
    }

    
    if(pwd=="")
    {
        document.getElementById("err1").innerHTML = " Enter Password Please!";
        return false;
    }

    if(pwd.length<3)
    {
        document.getElementById("err1").innerHTML = "Password must be atleast more than 3 characters!";
        return false;
    }

    
    if(account=="")
    {
        document.getElementById("err1").innerHTML = " Enter Account Type Please!";
        return false;
    }
}

function admin_reg_check()
{
    var fname = document.getElementById("fname").value;
    var lname = document.getElementById("lname").value;
    var mobile = document.getElementById("mobile").value;
    var dob = document.getElementById("dob").value;
    
    if(fname=="")
    {
        document.getElementById("err1").innerHTML = " Enter First Name Please!";
        return false;
    }

    if(fname.length<2)
    {
        document.getElementById("err1").innerHTML = " First Name must be atleast more than 2 characters!";
        return false;
    }

    
    if(lname=="")
    {
        document.getElementById("err1").innerHTML = " Enter Last Name Please!";
        return false;
    }

    if(lname.length<2)
    {
        document.getElementById("err1").innerHTML = " Last Name must be atleast more than 2 characters!";
        return false;
    }

    if(mobile=="")
    {
        document.getElementById("err1").innerHTML = " Enter Mobile Number Please!";
        return false;
    }

    if(mobile.length == 11)
    {
        document.getElementById("err1").innerHTML = " Invalid Mobile Number!";
        return false;
    }

    if(dob=="")
    {
        document.getElementById("err1").innerHTML = " Enter Date of Birth Please!";
        return false;
    }
}

function admin_reg1_check()
{
    var uname = document.getElementById("uname").value;
    var email = document.getElementById("email").value;
    var pwd = document.getElementById("pwd").value;
    var patt = /^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/;
    var res = patt.test(email);
    
    if(uname=="")
    {
        document.getElementById("err1").innerHTML = " Enter Uname Please!";
        return false;
    }

    if(uname.length<3)
    {
        document.getElementById("err1").innerHTML = "Username must be more than 3 characters";
        return false;
    }

    
    if(email=="")
    {
        document.getElementById("err1").innerHTML = " Enter Email Please!";
        return false;
    }

    if(!res)
    {
        document.getElementById("error").innerHTML="Email format is not correct";
        return false; 
    }

    
    if(pwd=="")
    {
        document.getElementById("err1").innerHTML = " Enter Password Please!";
        return false;
    }

    if(pwd.length<3)
    {
        document.getElementById("err1").innerHTML = "Password must be atleast more than 3 characters!";
        return false;
    }
}

function showmyuser()
{
    var uname=  document.getElementById("uname").value;
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
  
      if (this.readyState == 4 && this.status == 200) {
        document.getElementById("mytext").innerHTML = this.responseText;
      }
      else
      {
           document.getElementById("mytext").innerHTML = this.status;
      }
    };
    xhttp.open("POST", "../control/admin_search_ah_check.php", true);
    xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhttp.send("uname="+uname);
}

function showmyuser1()
{
    var uname1=  document.getElementById("uname1").value;
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
  
      if (this.readyState == 4 && this.status == 200) {
        document.getElementById("mytext1").innerHTML = this.responseText;
      }
      else
      {
           document.getElementById("mytext1").innerHTML = this.status;
      }
    };
    xhttp.open("POST", "../control/admin_search_emp_check.php", true);
    xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhttp.send("uname1="+uname1);
}

function showmyuser2()
{
    var uname2=  document.getElementById("uname2").value;
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
  
      if (this.readyState == 4 && this.status == 200) {
        document.getElementById("mytext2").innerHTML = this.responseText;
      }
      else
      {
           document.getElementById("mytext2").innerHTML = this.status;
      }
    };
    xhttp.open("POST", "../control/admin_search_utility_check.php", true);
    xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhttp.send("uname2="+uname2);
}