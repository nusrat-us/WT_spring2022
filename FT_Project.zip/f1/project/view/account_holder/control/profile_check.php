<?php
    require("../model/db.php");

    $connection = new db();
    $conobj=$connection->OpenCon();
    $uname = $_SESSION["uname"];
    $userQuery=$connection->Check_ah2($conobj,"account_holder",$uname);
    
    if($userQuery !== false && $userQuery->num_rows > 0)
    {
         while($row = $userQuery->fetch_assoc())
        {
            $_SESSION["id"]=$row["id"];
            $_SESSION["fname"]=$row["fname"];
            $_SESSION["lname"]=$row["lname"];
            $_SESSION["dob"]=$row["dob"];
            $_SESSION["uname"]=$row["uname"];
            $_SESSION["email"]=$row["email"];
            $_SESSION["pwd"]=$row["pwd"];
            $_SESSION["account"]=$row["account"];
        }
    }
?>