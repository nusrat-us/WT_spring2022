<?php
    session_start();
    include("../control/ah_reg2_check.php");
?>

<html>
    <head> 
        <link rel="stylesheet" type="text/css" href="../CSS/style1.css">
        <script src = "../js/validation.js"></script>
        <h2>Account Holder Registration 2</h2>
        <hr>
    </head>

    <body>
        <div class ="ah_login_reg">
            <form onsubmit="return ah_reg2_check()" method="POST">
                <input type="text" name="uname" id="uname" placeholder="Username"><?php echo $validateuname?>
                <br><br>
                <input type="email" name="email" id="email" placeholder="Email"><?php echo $validateemail?>
                <br><br>
                <input type="password" name="pwd" id="pwd" placeholder="Password"><?php echo $validatepwd?>
                <br><br>
                Account Type:<?php echo $validateaccount?> <br>
                <input type="radio" name="account" id="account" value="Normal Account">Normal Account
                <input type="radio" name="account" id="account" value="Fixed Account">Fixed Account
                <input type="radio" name="account" id="account" value="Savings Account">Savings Account
                <br><br>
                <a href="ah_reg1.php">Back</a>
                
                <input type="submit" name="submit" value="Next">

            </form>
            <p id="err3"></p>
        </div>
    </body>

</html>