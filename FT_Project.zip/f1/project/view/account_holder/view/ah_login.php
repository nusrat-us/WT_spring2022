<?php
    session_start();
    $msg="";
    include("../control/ah_login_check.php");
    
?>
<html>
    <link rel="stylesheet" type="text/css" href="../CSS/style1.css">
    
    <head>
        <script src = "../js/validation.js"></script>
        <h2>Account Holder Login Form</h2>
        <hr>
    </head>
    <body>
        <div class ="ah_login_reg">
            <form onsubmit="return ah_login_check()" method="POST">
                <input type="text" name="uname" id="uname" placeholder="Username">
                <br><br>
                <input type="password" name="pwd" id="pwd" placeholder="Password">
                <br><br>
                <input type = "checkbox" name = "remember">Remember Me<br><br>
                <input type="submit" name="sub" value="Log In">
            </form>
            <?php echo $msg ?>
            <p id="err1"></p>

            <h4><a href="ah_reg1.php" class="btn">Click here </a>to create an account</h4>
        </div>
    </body>

</html>
