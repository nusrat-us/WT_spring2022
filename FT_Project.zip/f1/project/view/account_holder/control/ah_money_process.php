<html>
<link rel="stylesheet" type="text/css" href="../CSS/style1.css">
</html>
<?php 

	$formdata = array(
        
	    'UserName'=>$_POST["uname1"],
        'Amount'=>$_POST["amount"],
        'Transactions'=>$_POST["r1"]
    );
    $existingdata = file_get_contents('../json/data.json');
    $tempJSONdata = json_decode($existingdata);
    $tempJSONdata[] =$formdata;
	$jsondata = json_encode($tempJSONdata, JSON_PRETTY_PRINT);

	if(isset($_POST["submit"]))
    {
        if(!empty($_POST["amount"]))
        {
            if(file_put_contents("../json/data.json", $jsondata)) 
            {
                $data = file_get_contents("../json/data.json");
                $mydata = json_decode($data);
                for ($x = 0; $x < 1; $x++) 
                { 
                        echo "Done";
?>
                        <html>
                            <body>
                                <br>
                                <a href="../view/ah_money.php">Back</a>
                            </body>
                        </html>
<?php                 
                }
    
            }
            else
            {
               echo "no data saved";
            }
        }
        else
        {
            echo "error0";
        }
    }
    else
    {
        echo "error2";
    }
 
?>