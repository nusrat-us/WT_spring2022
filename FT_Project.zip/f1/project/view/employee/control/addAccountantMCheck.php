<?php

include('../model/db.php');
 

$message="";
$Fname=$Lname=$Gender=$Dob=$Mobile=$Email=$Uname=$Password="";


if (isset($_POST['add'])) 
{
    $Fname=$_POST['fname'];
    $Lname=$_POST['lname'];
    
    $Dob=$_POST['dob'];
    $Mobile=$_POST['mobile'];
    $Email=$_POST['email'];
    $Uname=$_POST['username'];
    $Password=$_POST['password'];
    //$AccType=$_POST['acctype'];

    
        $connection = new db();
        $conobj=$connection->OpenCon();
    
        $userQuery=$connection->InsertAccountant($conobj,"employee",$Fname,$Lname,$_POST['gender'],$Dob,$Mobile,$Email,$_POST['jobpos'], $Uname,$Password);

        if ($userQuery==TRUE)
         {
 
            $message= "Added Successfuly ! ";
            
           }

          
         
        $connection->CloseCon($conobj);
    
}


?>