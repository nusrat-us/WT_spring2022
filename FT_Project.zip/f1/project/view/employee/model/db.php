<?php
class db{
 
function OpenCon()
 {
 $dbhost = "localhost";
 $dbuser = "root";
 $dbpass = "";
 $db = "bank";
 $conn = new mysqli($dbhost, $dbuser, $dbpass,$db);
 
 return $conn;
 }

 function InsertRegisteredData($conn,$table,$Fname,$Lname,$gender,$dob,$mobile,$email,$Jobpos,$Username,$Password )

 {
     $result=$conn-> query("INSERT INTO $table VALUES('$Fname','$Lname','$gender','$dob','$mobile','$email','$Jobpos','$Username','$Password')");
     return $result;
 }


 function CheckEmpManager($conn,$table,$username,$pwd)
 {
$result = $conn->query("SELECT * FROM ". $table." WHERE uname='". $username."' AND pwd='". $pwd."' AND jobpos='Manager'");
 return $result;
 }

 function CheckEmpAccountant($conn,$table,$username,$pwd)
 {
$result = $conn->query("SELECT * FROM ". $table." WHERE uname='". $username."' AND pwd='". $pwd."' AND jobpos='Accountant'");
 return $result;
 }

 function myProfile($conn,$table,$Uname)
 {
$result = $conn->query("SELECT * FROM ".$table." WHERE uname='". $Uname."'");
 return $result;
 }

 function UpdatemyProfile($conn,$table,$username,$fname,$lname,$gender,$dob,$email)
 {
     $sql = "UPDATE $table SET fname='$fname',lname='$lname',gender='$gender',dob='$dob', email='$email' WHERE uname='$username'";

    if ($conn->query($sql) === TRUE) {
        $result= TRUE;
    } else {
        $result= FALSE ;
    }
    return  $result;
 }

 function AccountHolderList($conn,$table)
 {
$result = $conn->query("SELECT * FROM  $table");
 return $result;
 }


function searchAccountHolder($conn,$table,$username)
 {
$result = $conn->query("SELECT * FROM ". $table." WHERE uname='". $username."'");
 return $result;
 }

 function InsertAccountHolder($conn,$table,$Fname,$Lname,$age,$Uname,$uid,$email,$Password,$accountType)

 {
     $result=$conn->query("INSERT INTO $table VALUES('$Fname','$Lname','$age','$Uname','$uid','$email','$Password','$accountType')");
     return $result;
 }

 function UpdateAccHolder($conn,$table,$username,$fname,$lname,$age,$uid,$email,$acctype)
 {
     $sql = "UPDATE $table SET fname='$fname',lname='$lname',age='$age',uid='$uid', email='$email',account='$acctype' WHERE uname='$username'";

    if ($conn->query($sql) === TRUE) {
        $result= TRUE;
    } else {
        $result= FALSE ;
    }
    return  $result;
 }

 function DeleteAccHolder($conn,$table,$uid)
 {
    $result=$conn->query("DELETE FROM $table WHERE uid=$uid");
    return $result;

 }

 function InsertAccountant($conn,$table,$Fname,$Lname,$Gender,$Dob,$Mobile,$Email,$Jobpos,$Uname,$Pwd)

 {
     $result=$conn-> query("INSERT INTO $table VALUES('$Fname','$Lname','$Gender','$Dob','$Mobile','$Email','$Jobpos','$Uname','$Pwd')");
     return $result;
 }

 function searchAccountant($conn,$table,$username)
 {
$result = $conn->query("SELECT * FROM ". $table." WHERE uname='". $username."' AND jobpos='Accountant'" );
 return $result;
 }


 function UpdateAccountant($conn,$table,$username,$fname,$lname,$Gender,$Dob,$Mobile,$Email)
 {
     $sql = "UPDATE $table SET fname='$fname',lname='$lname',gender='$Gender',dob='$Dob',mobile='$Mobile', email='$Email' WHERE uname='$username'";

    if ($conn->query($sql) === TRUE) {
        $result= TRUE;
    } else {
        $result= FALSE ;
    }
    return  $result;
 }
 function DeleteAccountant($conn,$table,$uname)
 {
    $result=$conn->query("DELETE FROM $table WHERE uname=$uname");
    return $result;

 }

 function InsertAccountInfo($conn,$table,$Uname,$AccNo,$CurrBalance,$AccType)

 {
     $result=$conn-> query("INSERT INTO $table VALUES('$Uname','$AccNo','$CurrBalance','$AccType')");
     return $result;
 }


function TransectionDetail($conn,$table)
 {
$result = $conn->query("SELECT * FROM  $table");
 return $result;
 }

 function LoanDetail($conn,$table)
 {
$result = $conn->query("SELECT * FROM  $table");
 return $result;
 }

 function viewAdminProfile($conn,$table)
 {
$result = $conn->query("SELECT * FROM  $table");
 return $result;
 }



 function ShowAll($conn,$table)
 {
$result = $conn->query("SELECT * FROM  $table");
 return $result;
 }

 


function CloseCon($conn)
 {
 $conn -> close();
 }
}
?>