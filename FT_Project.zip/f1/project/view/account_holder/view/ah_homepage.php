<?php
    session_start();
    include("../control/profile_check.php");

    if(empty($_SESSION["uname"]))
    {
        header("Location: ah_login.php");
    }
?>
<html>
    <link rel="stylesheet" type="text/css" href="../CSS/style1.css">
    <head>
       <h3> Welcome <?php echo $_SESSION["fname"]." ". $_SESSION["lname"] ?>
    </head>
    <body>
        <h5>
            
            <div class="navbar">
            <a href="ah_transaction.php">Make Transaction</a>
            <a href="ah_pay_bill.php">Pay Bill</a>
            <a href="ah_money.php">Deposite or Withdraw money</a>
            <div class="dropdown">
            <button class="dropbtn">Profile</button>
            <div class="dropdown-content">
                <a href="ah_search_ah.php">Search Account Holder Profile</a>
                <a href = "ah_profile.php">My Profile</a>
                <a href="ah_delete.php">Delete Account</a>
            </div>
            </div>
            <a id="logout" href="../control/logout.php">Log out</a>
            </div>
        </h5>
    </body>
</html>