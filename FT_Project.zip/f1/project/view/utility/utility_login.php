<?php
    session_start();
    include("../utility/control/utility_login_check.php")
?>

<html>
    <head>
        
        <link rel="stylesheet" href="css/style.css">
        <h1>Utility Login Page</h1>       
    </head>
    <hr>
    <body>
        <div class="login">
            <form onsubmit="return utility_login_check()" method="POST">
                <table>
                    <tr>
                        <td><lable for = "uname">UserName: </td>
                        <td><input type = "text" id ="uname" name = "uname"></td>
                        <td><?php echo $validateuname ?></td>
                    </tr>
                    <tr>
                        <td><lable for = "pwd">Password: </td>
                        <td><input type = "password" id ="pwd" name = "pwd"></td>
                        <td><td><?php echo $validatepwd ?> </td></td>                       
                    </tr>
                    <tr>
                        <td><input type = "checkbox" name = "rem">
                            <label for = "rem">Remember Me</td>
                    </tr>
                    <tr>
                        <td><input type = "submit" name= "submit" value = "Login"></td>
                    </tr>
                </table>
            </form>
            <p id="error"></p>
            <h4> For utility registration<a href = "../utility/view/utility_registration.php"> Click here!</a></h4>
            <h4> Go back to <a href = "../Homepage.php">Homepage</a></h4>
        </div>   
    </body>
</html>