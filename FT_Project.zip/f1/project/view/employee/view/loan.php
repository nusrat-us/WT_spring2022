<?php
include('../control/loan_check.php');
 
?>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="../CSS/accholderlist.css">
</head>
<body>
<div class="header"> 
<h1>Loan Deatils</h1>
</div>
<br><br>
<br><br>
<br><br>
<br><br>

<table class="center">
  <tr>
    <th>Loan Assigned To</th>
    <th>Loan Amount</th>
    <th>Interest Rate</th>
    <th>Loan Period</th>
    <th>Monthly Pay</th>
    <th>Amount Paid</th>
    
    
  </tr>
  <?php
  if($userQuery !== false && $userQuery->num_rows > 0 )
  {
      ?>

  
  <?php
  while($row = $userQuery->fetch_assoc())
  {
      ?>

  
  <tr>
    <td><?php echo $row["loan_assigned_to"];?></td>
    <td><?php echo $row["loan_amount"];?></td>
    <td><?php echo $row["interest_rate"];?></td>
    <td><?php echo $row["loan_period"];?></td>
    <td><?php echo $row["monthly_pay"];?></td>
    <td><?php echo $row["amount_paid"];?></td>
  </tr>

<?php

  }
  ?>
 <?php

}
?> 

  </table>

  <footer>

<a class="two" href="../view/ManagerPage.php">Previous Page</a>

<a class="one" href="../control/logout.php">Logout</a>
</footer>

</body>
</html>