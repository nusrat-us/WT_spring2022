-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 19, 2021 at 07:09 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bank`
--

-- --------------------------------------------------------

--
-- Table structure for table `account_holder`
--

CREATE TABLE `account_holder` (
  `id` int(11) NOT NULL,
  `fname` text NOT NULL,
  `lname` text NOT NULL,
  `dob` varchar(100) NOT NULL,
  `uname` text NOT NULL,
  `email` varchar(100) NOT NULL,
  `pwd` varchar(100) NOT NULL,
  `account` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `account_holder`
--

INSERT INTO `account_holder` (`id`, `fname`, `lname`, `dob`, `uname`, `email`, `pwd`, `account`) VALUES
(4, 'Akif', 'zaman', '1997-11-03', 'akif123', 'akifzaman101@yahoo.com', '12346', 'Savings Account'),
(3, 'Mohsina', 'khan', '1997-08-16', 'mohsina123', 'mohsinakhan645@gmail.com', '12345', 'Savings Account');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `fname` text NOT NULL,
  `lname` text NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `dob` varchar(100) NOT NULL,
  `uname` text NOT NULL,
  `email` varchar(100) NOT NULL,
  `pwd` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`fname`, `lname`, `mobile`, `dob`, `uname`, `email`, `pwd`) VALUES
('Akif', 'Zaman', '01758647896', '2021-10-18', 'akif123', 'akifzaman101@yahoo.com', 'akif@1234'),
('Mohsina', 'khan', '01775697205', '2021-10-16', 'Mohsina123', 'mohsinakhan645@gmail.com', 'Me-400@$');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `fname` text NOT NULL,
  `lname` text NOT NULL,
  `gender` varchar(100) NOT NULL,
  `dob` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `jobpos` varchar(100) NOT NULL,
  `uname` varchar(100) NOT NULL,
  `pwd` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`fname`, `lname`, `gender`, `dob`, `email`, `jobpos`, `uname`, `pwd`) VALUES
('Akif', 'Zaman', 'Male', '2021-10-12', 'akifzaman101@yahoo.com', 'Manager', 'akifzaman101', '456'),
('Akif', 'Zaman', 'Female', '2021-10-05', 'huntingthebeast102@yahoo.com', 'Accountant', 'fatima123', '123');

-- --------------------------------------------------------

--
-- Table structure for table `pay_bill`
--

CREATE TABLE `pay_bill` (
  `id` int(11) NOT NULL,
  `uname1` varchar(100) NOT NULL,
  `amount` varchar(100) NOT NULL,
  `uname2` varchar(100) NOT NULL,
  `bill` varchar(100) NOT NULL,
  `month` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pay_bill`
--

INSERT INTO `pay_bill` (`id`, `uname1`, `amount`, `uname2`, `bill`, `month`) VALUES
(5, 'mohsina123', '500', 'Utility', 'electricity', 'november'),
(6, 'mohsina123', '500', 'Utility', 'electricity', 'february'),
(7, 'mohsina123', '500', 'Utility', 'gas', 'february');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `uname1` text NOT NULL,
  `amount` int(100) NOT NULL,
  `uname2` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`uname1`, `amount`, `uname2`) VALUES
('akif123', 500, 'mohsina123'),
('Mohsina123', 500, 'akif123'),
('mohsina123', 5000, 'akif123'),
('mohsina123', 500, 'akif123'),
('mohsina123', 500, 'akif123');

-- --------------------------------------------------------

--
-- Table structure for table `utility`
--

CREATE TABLE `utility` (
  `fname` text NOT NULL,
  `lname` text NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `dob` varchar(100) NOT NULL,
  `uname` text NOT NULL,
  `email` varchar(100) NOT NULL,
  `pwd` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `utility`
--

INSERT INTO `utility` (`fname`, `lname`, `mobile`, `dob`, `uname`, `email`, `pwd`) VALUES
('Akif', 'Zaman', '01758647896', '2021-10-11', 'akif123', 'huntingthebeast102@yahoo.com', 'akif@123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account_holder`
--
ALTER TABLE `account_holder`
  ADD PRIMARY KEY (`uname`(100)),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`uname`(100)),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`uname`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `pay_bill`
--
ALTER TABLE `pay_bill`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `utility`
--
ALTER TABLE `utility`
  ADD PRIMARY KEY (`uname`(100)),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account_holder`
--
ALTER TABLE `account_holder`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `pay_bill`
--
ALTER TABLE `pay_bill`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
