<?php

include ("../control/updateAccHolderMcheck.php");


?>


<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="../CSS/updateaccholder.css">
</head>
<body>
<div class="header">
<h1>Update Account Holder Information</h1>
</div>

<br><br>
<br><br>
<br><br>

<div class="middlecolumn">
<form action="" method="post">




<label>Search Account holder</label>  
<input type="text" name="uname" placeholder="Search..">
<input type="submit"class="box1 search" name="search" value="Search">
</form>
<br><br>

<h2>Account Holder Info </h2>

<form method="post" action="" onsubmit="return updateValAccountHolderForm()" >
<table>
        <tr>
            <td><label>First Name:</label></td>
            <td><input type="text" name="fname" id="fname" value="<?php echo $fname; ?>" >  </td>  <td><p class="error" id="errorfname"></p></td>
        </tr>

        <tr>
            <td><label>Last Name:</label></td>
            <td><input type="text" name="lname" id="lname" value="<?php echo $lname; ?>"></td> <td><p class="error" id="errorlname"></p></td>
        </tr>

        <tr>
            <td><label>Age:</label></td>
            <td><input type="number" name="age" id="age" value="<?php echo $age; ?>"></td><td><p class="error" id="errorage"></p></td>
        </tr>


        <tr>
            <td><label>User Id:</label></td>
            <td><input type="text" name="uid" id="uid" value="<?php echo $uid; ?>"></td> <td><p class="error" id="erroruid"></p></td>
        </tr>
        <tr>
            <td><label>E-mail:</label></td>
            <td><input type="email" name="email" id="email" value="<?php echo $email; ?>"></td><td><p class="error" id="erroremail"></p></td>
        </tr>

        <tr>
            <td><label> Account Type:</label></td>
            <td>
            <input type="radio" id="Normal Account" name="acctype" value='Normal Account' <?php echo $radio1; ?>>
            <label for="Normal Account">Normal Account</label><br>

            <input type="radio" id="Saving Account" name="acctype" value='Saving Account' <?php echo $radio2; ?>>
            <label for="Saving Account">Saving Account</label><br>

            <input type="radio" id="Checking Account" name="acctype" value='Checking Account' <?php echo $radio3; ?>>
            <label for="Checking Account">Checking Account</label><br>

                         
     
            </td> 
            <td> <p class="error" id="erroracctype"></p></td>
        </tr>


        
        

        <tr>
            
            <td><input type="hidden" name="uname" id="uname" value="<?php echo $uname; ?>"> </td> <td>
        </tr>

        


        <tr>
            <td><input type="submit" class="box1 update" name="update" value="Update"></td>
        </tr>

        

    </table>

    <br><br>
    

    <?php

if(!empty($successmessage))
{
    echo "<div class='box success'>".$successmessage."</div>";
}

?>

    



</form>
</div>

<footer>

<a class="two" href="../view/AccountHolderPage.php">Previous Page</a>

<a class="one" href="../control/logout.php">Logout</a>
</footer>

<script src="../JS/myjs.js"></Script>
</body>
</html>

  


