<?php
    session_start();
    include("../control/ah_transaction_check.php");
    if(empty($_SESSION['uname']))
    {
        header("location: ah_login.php");
    }
?>
<html>
    <head>
    <link rel="stylesheet" type="text/css" href="../CSS/style1.css">
        <h1>Transaction Page</h1>
    </head>
    <body>
    <div class ="ah_login_reg">
            <form action="" method="POST">
                <table>
                    <tr>                    
                        <td><input type="hidden" id="uname1" name="uname1" value="<?php echo $_SESSION["uname"]?>"></td>
                        <td><?php echo $validateuname1 ?></td>                                                     
                    </tr>
                    <tr>
                        <td><label for="amount">Amount of Money:</label></td>                         
                        <td><input type="text" id="amount" name="amount"> 
                        <td><?php echo $validateamount ?></td>                                
                    </tr>
                    <tr>
                        <td><label for="uname2">Reciever UserName:</label></td>                       
                        <td><input type="text" id="uname2" name="uname2"></td> 
                        <td><?php echo $validateuname2 ?></td>                                    
                    </tr>                             
                    <tr>
                        <td><input name="submit" type="submit" value="Do Transaction"></td>
                        <td><a href = "ah_homepage.php">Back</a></td>                     
                    </tr>
                </table>           
            </form>
            <?php echo $msg  ?>
</div>
    </body>
</html>