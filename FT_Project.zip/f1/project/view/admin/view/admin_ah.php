<?php
    session_start();
    $msg1="";
    require("../model/db.php");
    include("../control/admin_ah_check.php");
?>
<html>
    <head>
        <link rel="stylesheet" href="../css/style.css">
        <h1>Account Holders</h1>
        <hr>        
    </head>
    <body>
        <div class="navbar">
            <a href = "../view/admin.php">Home</a>
            <a href = "../view/admin_search.php">Search Profiles</a>
            <div class="dropdown">
                <button class="dropbtn">Update and Delete users
                </button>
                <div class="dropdown-content">
                <a href = "../view/admin_ah.php">Account Holders</a>
                <a href = "../view/admin_emp.php">Employees</a>
                <a href = "../view/admin_utility.php">Utility</a>
                </div>
            </div>
            <div class="dropdown">
                <button class="dropbtn">Account
                </button>
                <div class="dropdown-content">
                <a href = "../view/admin_profile.php">Profile</a>
                <a href = "../control/logout.php">Log out</a>
                </div>
            </div>
        </div>
        <br><br>
<div class="ah">
<?php    
    $connection = new db();
    $conobj = $connection->OpenCon();

    $userQuery = $connection->ShowAll($conobj,"account_holder");

    if($userQuery !== false && $userQuery->num_rows > 0)
    {     
        echo "<table><tr><th>ID</th><th>First Name</th><th>Last Name</th><th>Age</th><th>Username</th><th>Email</th><th>Password</th><th>Account Type</th></tr>";
        while($row = $userQuery->fetch_assoc())
        {
            echo "<tr><td>".$row["id"]."</td><td>".$row["fname"]."</td><td>".$row["lname"]."</td><td>".$row["age"]."</td><td>".$row["uname"]."</td><td>".$row["email"]."</td><td>".$row["pwd"]."</td><td>".$row["account"]."</td></tr>";
        }
        echo "</table>";
    } 
    else 
    {
        echo "0 results";
    }
?>
<hr>
</div>   
        <br><br>
        
        <h2>Update or Delete Account Holder</h2>
        
        <form onsubmit="return admin_ah_check()" method="POST">
            <input type="text" name= "id" id="id" placeholder="Enter ID"><br><br>
            <input type="submit" class="Enter" name="enter" value="Enter">
        </form>
        <?php echo $msg1 ?>
        <p id="err"></p>
        
        <form onsubmit="return admin_ah_check2()" method="POST">
            <input type="hidden" name="id1" id="id1" value="<?php echo $id ?>"><br>
            <p class="text">First Name:</p><br><br>
            <input type="text" name="fname" id="fname" value="<?php echo $fname ?>"><br>
            <p class="text">Last Name:</p><br><br>
            <input type="text" name="lname" id="lname" value="<?php echo $lname ?>"><br>
            <p class="text">Age:</p><br><br>
            <input type="number" name="age" id="age" value="<?php echo $age ?>"><br>
            <p class="text">UserName:</p><br><br>
            <input type="text" name="uname" id="uname" value="<?php echo $uname ?>"><br>
            <p class="text">Email:</p><br><br>
            <input type="email" name="email" id="email" value="<?php echo $email ?>"><br>
            <p class="text">Password:</p><br><br>
            <input type="text" name="pwd" id="pwd" value="<?php echo $pwd ?>"><br>
            <p class="text">Account Type:</p><br><br>
            <input type="text" name="account" id="account" value="<?php echo $account ?>"><br><br>          
            <input type="submit" class="update" name="update" value="Update">
            <input type="submit" class="delete" name="delete" value="Delete">
        </form>
       <p class="msg" ><?php echo $msg ?></p>
        <p class="err" id="err1"></p>
        
    </body>
</html>