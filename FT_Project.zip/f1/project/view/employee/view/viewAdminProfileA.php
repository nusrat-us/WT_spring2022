<?php
include('../control/viewAdminProfileCheck.php');

if(empty($_SESSION["username"])) 
{
header("Location: ../control/login.php"); 
}

?>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="../CSS/showprofile.css">
</head>
<body>

<div class="header"> 
<h2>Admin Profile</h2>
</div>

<br><br>
<br><br>
<br><br>
<br><br>

<table class="center">
 
  <?php
  if($userQuery !== false && $userQuery->num_rows > 0 )
  {
      ?>

  
  <?php
  while($row = $userQuery->fetch_assoc())
  {
      ?>

  
  <tr>
    <th>First Name</th>
    <td><?php echo $row["fname"];?></td>
  </tr>
  <tr>
  <th>Last Name </th>
    <td><?php echo $row["lname"];?></td>
  </tr>
  <tr>
  <th>Mobile No</th>
    <td><?php echo $row["mobile"];?></td>
  </tr>
  <tr>
  <th>Date of Birth</th>
  <td><?php echo $row["dob"];?></td>
  </tr>
  <tr>
  <th>E-mail</th>

    <td><?php echo $row["email"];?></td>
  </tr>

<?php

  }
  ?>
 <?php

}
?> 

  </table>

  <footer>

<a class="two" href="../view/AccountantPage.php">Previous Page</a>

<a class="one" href="../control/logout.php">Logout</a>
</footer>

</body>
</html>