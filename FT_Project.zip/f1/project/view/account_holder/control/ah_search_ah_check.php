<?php
include("../model/db.php");

$user = $_POST['uname'];

if($user!="")
{
$connection = new db();
$conobj=$connection->OpenCon();

$MyQuery=$connection->Check_ah2($conobj,"account_holder",$user);



if ($MyQuery->num_rows > 0) {
    echo "<table><tr><th>First Name</th><th>Last Name</th><th>Date of Birth</th><th>UserName</th><th>Email</th></tr>";
    // output data of each row
    while($row = $MyQuery->fetch_assoc()) {
      echo "<tr><td>".$row["fname"]."</td><td>".$row["lname"]."</td><td>".$row["dob"]."</td><td>".$row["uname"]."</td><td>".$row["email"]."</td></tr>";
    }
    echo "</table>";
  } else {
    echo "0 results";
  }
}
else{
  echo "please enter something";
}
?>