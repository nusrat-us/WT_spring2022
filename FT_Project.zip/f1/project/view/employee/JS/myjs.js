function validateForm1() {
    var fname = document.getElementById("fname").value;
    var lname = document.getElementById("lname").value;
    var dob = document.getElementById("dob").value;
    var mobile = document.getElementById("mobile").value;
    var email = document.getElementById("email").value;
    var name_regex = /^[a-zA-Z\s]+$/;
    var email_regex = /^\S+@\S+\.\S+$/;
    var mob_regex = /^[0-9]+$/;
    //var mob_regex = /^[0][1-9]\d{10}$/;
    //var dob_regex =/^([0-9]{2})\/([0-9]{2})\/([0-9]{4})$/;
   
    if(name_regex.test(fname) === false)
    {
     document.getElementById("errorfname").innerHTML="Please enter a valid First name !";
     return false;

   } 
    
   if(fname.length<3)
    {
        document.getElementById("errorfname").innerHTML="First Name must be atleast 3 characters!";
        return false;

    }
   if(name_regex.test(lname) === false)
       {
        document.getElementById("errorlname").innerHTML="Please enter a valid Last name !";
       return false;

      } 
                     
     

    if(lname.length<3)
    {
        document.getElementById("errorlname").innerHTML="Last Name must be atleast 3 characters!";
        return false;

    }
                     
      

      
    if (document.getElementById("Male").checked == false &&  document.getElementById("Female").checked == false)
      {
        document.getElementById("errorgender").innerHTML="Please select any gender";
        return false;
        
      }

   if (dob == "") {
        document.getElementById("errordob").innerHTML="Date of Birth is required!";
        return false;
        
      }
      /*if(dob_regex.test(dob) === false)
      {
          document.getElementById("errordob").innerHTML="Please enter valid Date of birth !";
          return false;
      }*/

      /*if(mob_regex.test(mobile) === false)
    {
        document.getElementById("errormobile").innerHTML="Please enter valid Mobile Number !";
        return false;
    }*/

   if(mob_regex.test(mobile) === false)
    {
        document.getElementById("errormobile").innerHTML="Please enter valid Mobile Number !";
        return false;
    }

   if(mobile.length<11 || mobile.length>11)
    {
        document.getElementById("errormobile").innerHTML="Mobile number must be 11 digits !";
        return false;

    }
    
    

   if(email_regex.test(email) === false)
    {
      document.getElementById("erroremail").innerHTML="Please enter a valid email address !";
      return false;
    }
    
  }

  



  function validateForm3()
  {
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;

    if (document.getElementById("Manager").checked == false &&  document.getElementById("Accountant").checked == false)
      {
        document.getElementById("errorjobposition").innerHTML="Please select any Job Position !";
        return false;
        
      }
      if(username.length<3)
    {
        document.getElementById("errorusername").innerHTML="User Name must be atleast 3 characters!";
        return false;

    }
    if(password.length<3)
    {
        document.getElementById("errorpassword").innerHTML="Password must be atleast 3 characters!";
        return false;

    }

  }

  function MyAjaxFunc() {
    var username=document.getElementById("username").value;

    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        document.getElementById("demo").innerHTML = this.responseText;
      }
      else
      {
           document.getElementById("demo").innerHTML = this.status;
      }
    };
    xhttp.open("POST", "../control/searchAccountHolderCheck.php", true);
   
    xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhttp.send("username="+username);
  
  
  
   
  }

  function AddAccHolderFormVal()
  {
    var fname=document.getElementById("fname").value;
    var lname=document.getElementById("lname").value;
    var age=document.getElementById("age").value;
    var uname=document.getElementById("uname").value;
    var uid=document.getElementById("uid").value;
    var email=document.getElementById("email").value;
    var pwd=document.getElementById("pwd").value;
    
    var name_regex = /^[a-zA-Z\s]+$/;
    var email_regex = /^\S+@\S+\.\S+$/;
    var num_regex = /^[0-9]+$/;

    if(fname == "")
    {
        document.getElementById("errorfname").innerHTML="first name can not be empty !";
        return false;
    }

    if(fname.length<3)
    {
        document.getElementById("errorfname").innerHTML="first name must be atleast 3 characters!";
        return false;

    }
                     
      if(name_regex.test(fname) === false)
       {
        document.getElementById("errorfname").innerHTML="Please enter a valid name";
        return false;

      } 
  
    
     
    
     if(lname == "")
    {
        document.getElementById("errorlname").innerHTML="last name can not be empty !";
        return false;
    }

     if(lname.length<3)
    {
        document.getElementById("errorlname").innerHTML="last name must be atleast 3 characters!";
        return false;

    }
               
      if(name_regex.test(lname) === false)
       {
        document.getElementById("errorlname").innerHTML="Please enter a valid name";
        return false;

      } 
  

     if(age == "")
    {
        document.getElementById("errorage").innerHTML="Age is required !";
        return false;
    }

    if(num_regex.test(age) === false)
    {
        document.getElementById("errorage").innerHTML="Please enter valid age !";
        return false;
    }

    if(uname == "")
    {
        document.getElementById("erroruname").innerHTML="User name can not be empty !";
        return false;
    }

    if(uname.length<3)
    {
        document.getElementById("erroruname").innerHTML="User name must be atleast 3 characters!";
        return false;

    }



    if(uid =="")
    {
        document.getElementById("erroruid").innerHTML="User Id can not be empty !";
        return false;
    }
    if(num_regex.test(uid) === false)
    {
        document.getElementById("erroruid").innerHTML="Please enter number !";
        return false;
    }

    if(email == "")
    {
        document.getElementById("erroremail").innerHTML="Email can not be empty !";
        return false;
    }
    if(email_regex.test(email) === false)
    {
      document.getElementById("erroremail").innerHTML="Please enter a valid email address !";
      return false;
    }
    if(pwd == "")
    {
        document.getElementById("errorpwd").innerHTML="Password can not be empty !";
        return false;
    }

    if(pwd.length<3)
    {
        document.getElementById("errorpwd").innerHTML="Password must be atleast 3 characters!";
        return false;

    }



    if (document.getElementById("Normal Account").checked == false &&  document.getElementById("Saving Account").checked == false &&  document.getElementById("Checking Account").checked == false)
    {
      document.getElementById("erroracctype").innerHTML="Please select any Account Type !";
      return false;
      
    }
    
    
}
    
  

  function updateValAccountHolderForm()
  {
    var fname=document.getElementById("fname").value;
    var lname=document.getElementById("lname").value;
    var age=document.getElementById("age").value;
    var uid=document.getElementById("uid").value;
    var email=document.getElementById("email").value;
    //var acctype=document.getElementById("acctype").value;
    var name_regex = /^[a-zA-Z\s]+$/;
    var email_regex = /^\S+@\S+\.\S+$/;
    var age_regex = /^[0-9]+$/;

    if(fname == "")
    {
        document.getElementById("errorfname").innerHTML="first name can not be empty !";
        return false;
    }

    if(fname.length<3)
    {
        document.getElementById("errorfname").innerHTML="first name must be atleast 3 characters!";
        return false;

    }
                     
      if(name_regex.test(fname) === false)
       {
        document.getElementById("errorfname").innerHTML="Please enter a valid name";
        return false;

      } 
  
    
     
    
     if(lname == "")
    {
        document.getElementById("errorlname").innerHTML="last name can not be empty !";
        return false;
    }

     if(lname.length<3)
    {
        document.getElementById("errorlname").innerHTML="last name must be atleast 3 characters!";
        return false;

    }
               
      if(name_regex.test(lname) === false)
       {
        document.getElementById("errorlname").innerHTML="Please enter a valid name";
        return false;

      } 
  

     if(age == "")
    {
        document.getElementById("errorage").innerHTML="Age is required !";
        return false;
    }

    if(age_regex.test(age) === false)
    {
        document.getElementById("errorage").innerHTML="Please enter valid age !";
        return false;
    }



    if(uid =="")
    {
        document.getElementById("erroruid").innerHTML="User Id can not be empty !";
        return false;
    }

    if(email == "")
    {
        document.getElementById("erroremail").innerHTML="Email can not be empty !";
        return false;
    }
    if(email_regex.test(email) === false)
    {
      document.getElementById("erroremail").innerHTML="Please enter a valid email address !";
      return false;
    }

    if (document.getElementById("Normal Account").checked == false &&  document.getElementById("Saving Account").checked == false &&  document.getElementById("Checking Account").checked == false)
      {
        document.getElementById("erroracctype").innerHTML="Please select any Account Type !";
        return false;
        
      }
    
    
}

function AddAccountantFormVal()
{
  var fname = document.getElementById("fname").value;
    var lname = document.getElementById("lname").value;
    var dob = document.getElementById("dob").value;
    var mobile = document.getElementById("mobile").value;
    var email = document.getElementById("email").value;
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;
    var name_regex = /^[a-zA-Z\s]+$/;
    var email_regex = /^\S+@\S+\.\S+$/;
    var mob_regex = /^[0-9]+$/;
    //var mob_regex = /^[0][1-9]\d{10}$/;
    //var dob_regex =/^([0-9]{2})\/([0-9]{2})\/([0-9]{4})$/;
   
    if(name_regex.test(fname) === false)
    {
     document.getElementById("errorfname").innerHTML="Please enter a valid First name !";
     return false;

   } 
    
   if(fname.length<3)
    {
        document.getElementById("errorfname").innerHTML="First Name must be atleast 3 characters!";
        return false;

    }
   if(name_regex.test(lname) === false)
       {
        document.getElementById("errorlname").innerHTML="Please enter a valid Last name !";
       return false;

      } 
                     
     

    if(lname.length<3)
    {
        document.getElementById("errorlname").innerHTML="Last Name must be atleast 3 characters!";
        return false;

    }
                     
      

      
    if (document.getElementById("Male").checked == false &&  document.getElementById("Female").checked == false)
      {
        document.getElementById("errorgender").innerHTML="Please select any gender";
        return false;
        
      }

   if (dob == "") {
        document.getElementById("errordob").innerHTML="Date of Birth is required!";
        return false;
        
      }
      /*if(dob_regex.test(dob) === false)
      {
          document.getElementById("errordob").innerHTML="Please enter valid Date of birth !";
          return false;
      }*/

      /*if(mob_regex.test(mobile) === false)
    {
        document.getElementById("errormobile").innerHTML="Please enter valid Mobile Number !";
        return false;
    }*/

   if(mob_regex.test(mobile) === false)
    {
        document.getElementById("errormobile").innerHTML="Please enter valid Mobile Number !";
        return false;
    }

   if(mobile.length<11 || mobile.length>11)
    {
        document.getElementById("errormobile").innerHTML="Mobile number must be 11 digits !";
        return false;

    }
    
    

   if(email_regex.test(email) === false)
    {
      document.getElementById("erroremail").innerHTML="Please enter a valid email address !";
      return false;
    }
    if (document.getElementById("Accountant").checked == false)
    {
      document.getElementById("errorjobpos").innerHTML="Please select Job Position !";
      return false;
      
    }



      if(username.length<3)
    {
        document.getElementById("errorusername").innerHTML="User Name must be atleast 3 characters!";
        return false;

    }
    if(password.length<3)
    {
        document.getElementById("errorpassword").innerHTML="Password must be atleast 3 characters!";
        return false;

    }

}

function updateAccountantFormVal()
{
  var fname = document.getElementById("fname").value;
    var lname = document.getElementById("lname").value;
    var dob = document.getElementById("dob").value;
    var mobile = document.getElementById("mobile").value;
    var email = document.getElementById("email").value;
    //var username = document.getElementById("username").value;
    //var password = document.getElementById("password").value;
    var name_regex = /^[a-zA-Z\s]+$/;
    var email_regex = /^\S+@\S+\.\S+$/;
    var mob_regex = /^[0-9]+$/;
    //var mob_regex = /^[0][1-9]\d{10}$/;
    //var dob_regex =/^([0-9]{2})\/([0-9]{2})\/([0-9]{4})$/;
   
    if(name_regex.test(fname) === false)
    {
     document.getElementById("errorfname").innerHTML="Please enter a valid First name !";
     return false;

   } 
    
   if(fname.length<3)
    {
        document.getElementById("errorfname").innerHTML="First Name must be atleast 3 characters!";
        return false;

    }
   if(name_regex.test(lname) === false)
       {
        document.getElementById("errorlname").innerHTML="Please enter a valid Last name !";
       return false;

      } 
                     
     

    if(lname.length<3)
    {
        document.getElementById("errorlname").innerHTML="Last Name must be atleast 3 characters!";
        return false;

    }
                     
      

      
    if (document.getElementById("Male").checked == false &&  document.getElementById("Female").checked == false)
      {
        document.getElementById("errorgender").innerHTML="Please select any gender";
        return false;
        
      }

   if (dob == "") {
        document.getElementById("errordob").innerHTML="Date of Birth is required!";
        return false;
        
      }
      /*if(dob_regex.test(dob) === false)
      {
          document.getElementById("errordob").innerHTML="Please enter valid Date of birth !";
          return false;
      }*/

      /*if(mob_regex.test(mobile) === false)
    {
        document.getElementById("errormobile").innerHTML="Please enter valid Mobile Number !";
        return false;
    }*/

   if(mob_regex.test(mobile) === false)
    {
        document.getElementById("errormobile").innerHTML="Please enter valid Mobile Number !";
        return false;
    }

   if(mobile.length<11 || mobile.length>11)
    {
        document.getElementById("errormobile").innerHTML="Mobile number must be 11 digits !";
        return false;

    }
    
    

   if(email_regex.test(email) === false)
    {
      document.getElementById("erroremail").innerHTML="Please enter a valid email address !";
      return false;
    }
    

}



function AddAccInfoVal()
  {
    var uname=document.getElementById("uname").value;
    var accNo=document.getElementById("accNo").value;
    var currbalance=document.getElementById("currbalance").value;
  
    
    var name_regex = /^[a-zA-Z\s]+$/;
    
    var num_regex = /^[0-9]+$/;

    if(uname == "")
    {
        document.getElementById("erroruname").innerHTML="User name can not be empty !";
        return false;
    }

    if(uname.length<3)
    {
        document.getElementById("erroruname").innerHTML="User name must be atleast 3 characters!";
        return false;

    }
                     
      if(name_regex.test(uname) === false)
       {
        document.getElementById("erroruname").innerHTML="Please enter a valid user name";
        return false;

      } 
  
    
       if(accNo == "")
    {
        document.getElementById("erroraccNo").innerHTML="Bank Account No is required !";
        return false;
    }

    if(accNo.length<3)
    {
        document.getElementById("erroraccNo").innerHTML="Bank Account No must be atleast 3 characters!";
        return false;

    }

    if(num_regex.test(accNo) === false)
    {
        document.getElementById("erroraccNo").innerHTML="Please enter valid Account no !";
        return false;
    }

    
    if(currbalance == "")
    {
        document.getElementById("errorcurrbalance").innerHTML="Please enter Balance !";
        return false;
    }


    if(num_regex.test(currbalance) === false)
    {
        document.getElementById("errorcurrbalance").innerHTML="Please enter valid Balance !";
        return false;
    }

    if (document.getElementById("Normal Account").checked == false &&  document.getElementById("Saving Account").checked == false &&  document.getElementById("Checking Account").checked == false)
    {
      document.getElementById("erroracctype").innerHTML="Please select any Account Type !";
      return false;
      
    }
    
    
}
    
    
    
    


    
