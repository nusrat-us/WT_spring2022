<?php

   require("../model/db.php");

   $validateuname="";
   $validatepwd="";
   $uname ="";
   $pwd="";
   

   if(isset($_POST['sub']))
   {
         
       if(empty($_REQUEST['uname']))
       {
            $validateuname = "  Enter your username PLEASE!";
       }
       else
       {
            $validateuname = "";          
       }
       if(empty($_REQUEST['pwd']))
       {
            $validatepwd = "  Enter your password PLEASE!";
       }
       else
       {
            $validatepwd = "";          
       }

       if($validateuname == "" && $validatepwd == "")
       {
            
            $uname = $_POST['uname'];
            $pwd = $_POST['pwd'];
            $connection = new db();
            $conobj = $connection->OpenCon();
            $userQuery = $connection->Check_ah($conobj,"account_holder",$uname,$pwd);
            if($userQuery !== false && $userQuery->num_rows > 0)
            {
                $_SESSION['uname'] = $uname;
                $_SESSION['pwd'] = $pwd;
                
                if($_SESSION['uname'] == $uname && $_SESSION['pwd'] == $pwd)
                {
                    if(isset($_POST['remember']))
                    {
                        setcookie('uname', $_SESSION['uname'], time()+60*60*10);                    
                        header("location: ../view/ah_homepage.php");
                                               
                    }
                    else
                    {
                        $_SESSION['uname'] = $_REQUEST['uname'];
                        $_SESSION['pwd'] = $_REQUEST['pwd'];
                        header("location: ../view/ah_homepage.php"); 
                                                                
                    }
                }
                else
                {
                    header("location: ../view/ah_homepage.php");
                                  
                }
            }
            else
            {
                $msg= "Wrong Username or Password";
                
            }
       }
       else
       {
            $msg= "Enter username and password please!";
            
       }
   }
?>

