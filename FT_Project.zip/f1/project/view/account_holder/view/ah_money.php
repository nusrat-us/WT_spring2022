<?php
    session_start();
    include("../control/ah_money_check.php");
    if(empty($_SESSION['uname']))
    {
        header("location: ah_login.php");
    }
?>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="../CSS/style1.css">
        <script src="../js/validation.js"></script>
        <h1>Deposite and Withdraw page</h1>
    </head>
    <body>
        <div class ="ah_login_reg">
            <form action="../control/ah_money_process.php" method="POST">
                <table>
                    <tr>                       
                        <td><input type="hidden" id="uname1" name="uname1" value = "<?php echo $_SESSION["uname"] ?>"></td>
                        <td><?php echo $validateuname1 ?></td>                                                     
                    </tr>
                    <tr>
                        <td><label for="amount">amount:</label></td>                         
                        <td><input type="text" id="amount" name="amount"> 
                        <td><?php echo $validateamount ?></td>                                
                    </tr>
                    <tr>
                        <td><label for="Transaction">Transaction:</label></td>                       
                        <td>
                            <input type="radio" id="dep" name="r1" value="deposite">
                            <label for="deposite">Deposite</label>
                            <input type="radio" id="wid" name="r1" value="withdraw">
                            <label for="withdraw">Withdraw</label>
                        </td>
                                                                                                          
                    </tr>                          
                    <tr>
                        <td><input name="submit" type="submit" value="Enter"></td>
                        <td><a href = "ah_homepage.php">Back</a></td>                     
                    </tr>
                </table>           
            </form>
            <?php echo $msg ?>
            <br><br><br><br>
            <input type="hidden" id="history" name="history" value="<?php echo $_SESSION["uname"]?>">
            <button onclick="money_history()">History</button>
            <br><br>
            <p id="text"></p>
        </div>
    </body>
</html>