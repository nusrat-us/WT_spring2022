<?php
    session_start();
    $uname=$email=$pwd="";
    if(!empty($_SESSION["uname"]))
    {
        $uname=$_SESSION["uname"];
        $email=$_SESSION["email"];
        $pwd=$_SESSION["pwd"];
    }
    include("../control/admin_registration1_check.php");
?>

<html>
    <head> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src = "js/jquery.js"></script>
        <link rel="stylesheet" href="../css/style.css"></link>
        <link rel="stylesheet" href="../css/style1.css"></link> 
        <script src = "../js/admin_login_check.js"></script>          
        <h1>Admin Registration Form</h1>
    </head>
    <hr>
    <body> 
        <div class="login_reg">       
            <form  method = "POST" action ="">
                <table>
                    <tr>
                        <td><label for = "uname" >UserName:</td>
                        <td><input type = "text" id = "uname" name = "uname" value="<?php echo $uname ?>"></td>
                        <td><?php echo $validateuname ?> </td>
                    </tr>
                    <tr>
                        <td><label for = "email" >Email:</td>
                        <td><input type = "email" id = "email" name = "email" value="<?php echo $email ?>"></td>
                        <td><?php echo $validateemail ?> </td>
                    </tr>
                    <tr>
                        <td><label for = "pwd" >Password:</td>
                        <td><input type = "password" id = "pwd" name = "pwd" value="<?php echo $pwd ?>"></td>
                        <td><?php echo $validatepwd ?> </td>
                    </tr>
                    <tr>
                        <td><input type="submit" class="login_reg_button" name = "back1" value="Back"></td>
                        <td><input type = "submit" class="login_reg_button" name = "next2" value = "Next"></td>
                    </tr>
                </table>
            </form>
            <p id="err1"></p> 
        </div>               
    </body>
</html>