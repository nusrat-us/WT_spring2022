<?php
    class db
    {
        function OpenCon()
        {
            $dbhost = "localhost";
            $dbuser = "root";
            $dbpass = "";
            $db = "bank";
    
            $conn = new mysqli($dbhost, $dbuser, $dbpass, $db);

            return $conn;
        }

        function CheckUser($conn, $table, $username, $password)
        {
            $result = $conn->query("SELECT * FROM ". $table." WHERE uname='". $username."' AND pwd='". $password."'");
            return $result;
        }

        function ShowAll($conn,$table)
        {
            $result = $conn->query("SELECT * FROM $table");
            return $result;
        }

        function Check_ah($conn, $table, $id)
        {
            $result = $conn->query("SELECT * FROM ". $table." WHERE id='". $id."'");
            return $result;          
        }

        function Check_emp($conn, $table, $id)
        {
            $result = $conn->query("SELECT * FROM ". $table." WHERE id='". $id."'");
            return $result;          
        }

        function Update_ah($conn, $table, $id, $fname, $lname, $age, $uname, $email, $pwd, $account)
        {
            $result = $conn->query("UPDATE $table SET fname ='$fname', lname='$lname', age='$age', uname='$uname', email='$email', pwd='$pwd', account='$account' WHERE id='$id'");
            return $result;       
        }

        function Update_emp($conn, $table, $id, $fname, $lname, $gender, $dob, $email, $jobpos, $uname, $pwd)
        {
            $result = $conn->query("UPDATE $table SET fname ='$fname', lname='$lname', gender='$gender', dob='$dob', email='$email', jobpos='$jobpos', uname='$uname', pwd='$pwd' WHERE id='$id'");
            return $result;       
        }

        function Update_utility($conn, $table, $id, $fname, $lname, $mobile, $dob, $uname, $email, $pwd)
        {
            $result = $conn->query("UPDATE $table SET fname ='$fname', lname='$lname', mobile='$mobile', dob='$dob', uname='$uname', email='$email', pwd='$pwd' WHERE id='$id'");
            return $result;       
        }

        function ViewProfile($conn,$table,$uname)
        {
            $result = $conn->query("SELECT * FROM ". $table." WHERE uname='". $uname."'");
            return $result;
        }

        function UpdateProfile($conn, $table, $id, $fname, $lname, $mobile, $dob, $uname, $email, $pwd)
        {
            $result = $conn->query("UPDATE $table SET fname ='$fname', lname='$lname', mobile='$mobile', dob='$dob', uname='$uname', email='$email', pwd='$pwd' WHERE id='$id'");
            return $result;       
        }

        function Delete($conn,$table,$uname)
        {
            $result = $conn->query("DELETE FROM ". $table." WHERE uname='". $uname."'");
            return $result;
        }

        function CloseCon($conn)
        {
            $conn->close();
        }
    }
?>