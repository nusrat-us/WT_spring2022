<?php
    $msg=$fname=$lname=$mobile=$dob=$uname=$id=$email=$pwd="";
    
    if(isset($_POST["enter"]))
    {
        $connection = new db();
        $conobj=$connection->OpenCon();
        $userQuery=$connection->Check_ah($conobj,"utility",$_POST["id"]);
        
        
        if($userQuery !== false && $userQuery->num_rows > 0) 
        {
            while($row = $userQuery->fetch_assoc()) 
            {
                $id = $row["id"];
                $fname = $row["fname"];
                $lname = $row["lname"];
                $mobile = $row["mobile"];
                $dob = $row["dob"];
                $uname = $row["uname"];
                $email = $row["email"];
                $pwd = $row["pwd"];
            }
        } 
        else 
        {
            echo "0 results";
        }
    }

    if(isset($_POST["update"]))
    {
        $id = $_POST["id1"];
        $fname = $_POST["fname"];
        $lname = $_POST["lname"];
        $mobile = $_POST["mobile"];
        $dob = $_POST["dob"];
        $uname = $_POST["uname"];
        $email = $_POST["email"];
        $pwd = $_POST["pwd"];

        $connection = new db();
        $conobj=$connection->OpenCon();
        $userQuery=$connection->Update_utility($conobj,"utility", $id, $fname, $lname, $mobile, $dob, $uname, $email,  $pwd);

        if($conobj->query($userQuery) != TRUE) 
        {
            $msg = "Updated successfully!";
        }
        else 
        {
            $msg = "Update Failed!";
        }
     
    }

    if(isset($_POST["delete"]))
    {
        $id = $_POST["id1"];
        $fname = $_POST["fname"];
        $lname = $_POST["lname"];
        $mobile = $_POST["mobile"];
        $dob = $_POST["dob"];
        $uname = $_POST["uname"];
        $email = $_POST["email"];
        $pwd = $_POST["pwd"];

        $connection = new db();
        $conobj=$connection->OpenCon();
        $userQuery=$connection->Delete($conobj,"utility", $uname);

        if($conobj->query($userQuery) != TRUE) 
        {
            $msg = "Deleted successfully!";
        }
        else 
        {
            $msg = "Delete Failed!";
        }
     
    }
?>