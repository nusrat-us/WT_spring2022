<?php

session_start(); 
if(empty($_SESSION["username"]) && empty($_SESSION["password"]) ) 
{
header("Location: ../view/HomePage.php"); 
}

?>


<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="../CSS/manager.css">
</head>
<body>

<div class="header">
<h1> Manager Page </h1>
<h3>Welcome <?php echo $_SESSION["username"];?></h3>
</div>

<div class="sticky">
<div class="topnav">


<a href="../view/viewAdminProfile.php">View Admin Profile</a>

<a href="../view/AccountHolderPage.php">Manage Account Holder</a>

<a href="../view/AccountantM.php">Manage Accountant</a>

<a href="../view/loan.php">Manage Loan</a>


  

<div class="dropdown">
<button class="dropbtn">Your Profile</button>
  <div class="dropdown-content">
  <a href="../view/ShowProfileM.php">View Profile</a>
  <br>
  <br>
  <a href="../view/editProfileM.php">Edit Profile</a>
  
  </div>
</div>

</div>


</div>
<br>
<br>
<br>
<br>

<form action="../control/process.php" method="post" >
    <table>
        <tr>
            <td>Notice:</td>
            <td><textarea id="notice" name="notice" rows="4" cols="50"></textarea></td>
        </tr>

        <tr>
            <td><input type="submit" name="Insert" value="Insert"></td>
        </tr>
    
    </table>

</form>
<footer>

<a class="one" href="../control/logout.php">Logout</a>

</footer>

</body>
</html>

