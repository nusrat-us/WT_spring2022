<?php
    include('../model/db.php');

    $user = $_POST['uname'];

    if($user!="")
    {
        $connection = new db();
        $conobj=$connection->OpenCon();

        $MyQuery=$connection->ViewProfile($conobj,"account_holder",$user );



        if($MyQuery !== false && $MyQuery->num_rows > 0)
        {       
            echo "<table><tr><th>ID</th><th>First Name</th><th>Last Name</th><th>Age</th><th>Username</th><th>Email</th><th>Password</th><th>Account Type</th></tr>";
            while($row = $MyQuery->fetch_assoc())
            {
                 echo "<tr><td>".$row["id"]."</td><td>".$row["fname"]."</td><td>".$row["lname"]."</td><td>".$row["age"]."</td><td>".$row["uname"]."</td><td>".$row["email"]."</td><td>".$row["pwd"]."</td><td>".$row["account"]."</td></tr>";
            }
            echo "</table>";
        } 
        else 
        {
            echo "0 results";
        }

    }

?>
