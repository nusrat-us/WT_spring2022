<?php
    include('../model/db.php');

    $user1 = $_POST['uname1'];


    if($user1!="")
    {
        $connection = new db();
        $conobj=$connection->OpenCon();

        $MyQuery=$connection->ViewProfile($conobj,"employee",$user1);



        if($MyQuery !== false && $MyQuery->num_rows > 0)
        {       
            echo "<table><tr><th>ID</th><th>First Name</th><th>Last Name</th><th>Gender</th><th>Date Of Birth</th><th>Email</th><th>Job position</th><th>uname</th><th>Password</th></tr>";
            while($row = $MyQuery->fetch_assoc())
            {
                    echo "<tr><td>".$row["id"]."</td><td>".$row["fname"]."</td><td>".$row["lname"]."</td><td>".$row["gender"]."</td><td>".$row["dob"]."</td><td>".$row["email"]."</td><td>".$row["jobpos"]."</td><td>".$row["uname"]."</td><td>".$row["pwd"]."</td></tr>";
            }
            echo "</table>";
        } 
        else 
        {
            echo "0 results";
        }
    }
?>