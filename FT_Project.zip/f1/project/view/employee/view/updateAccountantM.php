<?php

include ("../control/updateAccountantMcheck.php");


?>


<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="../CSS/updateaccholder.css">
</head>
<body>
<div class="header">
<h1>Update Accountant Information</h1>
</div>

<br><br>
<br><br>
<br><br>

<div class="middlecolumn">
<form action="" method="post">




<label>Search Accountant</label>  
<input type="text" name="username" placeholder="Search..">
<input type="submit" name="search" value="Search">
</form>
<br><br>

<h2>Accountant Info </h2>

<form method="post" action="" onsubmit="return updateAccountantFormVal()" >
<table>
        <tr>
            <td><label>First Name:</label></td>
            <td><input type="text" name="fname" id="fname" value="<?php echo $fname; ?>" >  </td>  <td><p class="error" id="errorfname"></p></td>
        </tr>

        <tr>
            <td><label>Last Name:</label></td>
            <td><input type="text" name="lname" id="lname" value="<?php echo $lname; ?>"></td> <td><p class="error" id="errorlname"></p></td>
        </tr>
        <tr>
            <td><label> Gender:</label></td>
            <td>
            <input type="radio" id="Male" name="gender" value='Male' <?php echo $radio1; ?>>
            <label for="Male">Male</label>

            <input type="radio" id="Female" name="gender" value='Female' <?php echo $radio2; ?>>
            <label for="Female">Female</label>

                         
     
            </td> 
            <td> <p class="error" id="errorgender"></p></td>
        </tr>

        <tr>
            <td><label>Date of Birth:</label></td>
            <td><input type="date" name="dob" id="dob" value="<?php echo $dob; ?>"></td> <td> <p class="error" id="errordob"></p></td>
        </tr>

        <tr>
            <td><label>Mobile:</label></td>
            <td><input type="text" name="mobile" id="mobile" value="<?php echo $mobile; ?>"></td> <td> <p class="error" id="errormobile"></p></td>
        </tr>


        <tr>
            <td><label for="email">E-mail:</label></td>
            <td><input type="text" name="email" id="email" value="<?php echo $email; ?>"></td> <td> <p class="error" id="erroremail"></p></td>
        </tr>


        <tr>
            
            <td><input type="hidden" name="username" id="username" value="<?php echo $uname; ?>"> </td> 
        </tr>

        


        <tr>
            <td><input type="submit" class="box1 update" name="update" value="Update"></td>
        </tr>

        

    </table>

    <br><br>
    

    <?php

if(!empty($successmessage))
{
    echo "<div class='box success'>".$successmessage."</div>";
}

?>

    



</form>
</div>

<footer>

<a class="two" href="../view/AccountantM.php">Previous Page</a>

<a class="one" href="../control/logout.php">Logout</a>
</footer>

<script src="../JS/myjs.js"></Script>
</body>
</html>
