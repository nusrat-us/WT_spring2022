<?php
include('../control/viewTransactionCheck.php');
 
?>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="../CSS/accholderlist.css">
</head>
<body>
<div class="header"> 
<h1>Transaction Detail</h1>
</div>
<br><br>
<br><br>
<br><br>
<br><br>

<table class="center">
  <tr>
    <th>From</th>
    <th>Amount</th>
    <th>To</th>
    
    
  </tr>
  <?php
  if($userQuery !== false && $userQuery->num_rows > 0 )
  {
      ?>

  
  <?php
  while($row = $userQuery->fetch_assoc())
  {
      ?>

  
  <tr>
    <td><?php echo $row["uname1"];?></td>
    <td><?php echo $row["amount"];?></td>
    <td><?php echo $row["uname2"];?></td>
  </tr>

<?php

  }
  ?>
 <?php

}
?> 

  </table>

  <footer>

<a class="two" href="../view/AccountantPage.php">Previous Page</a>

<a class="one" href="../control/logout.php">Logout</a>
</footer>

</body>
</html>