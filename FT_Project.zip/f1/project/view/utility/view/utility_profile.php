<?php
    session_start();
    require("../model/db.php");
    include("../control/utility_profile_check.php")
?>
<html>
    <head>
        <link rel="stylesheet" href="../css/style.css">
       <h2>Utility profile of <?php echo $_SESSION["fname"]." ".$_SESSION["lname"] ?></h2>
    </head>
</html>
<?php

    $connection = new db();
    $conobj=$connection->OpenCon();
    $uname = $_SESSION["uname"];
    $userQuery=$connection->ViewProfile($conobj,"utility",$uname);
    
    if($userQuery !== false && $userQuery->num_rows > 0) 
    {
        while($row = $userQuery->fetch_assoc()) 
        {
            $_SESSION["id"]=$row["id"];
            $_SESSION["fname"]=$row["fname"];
            $_SESSION["lname"]=$row["lname"];
            $_SESSION["mobile"]=$row["mobile"];
            $_SESSION["dob"]=$row["dob"];
            $_SESSION["uname"]=$row["uname"];
            $_SESSION["email"]=$row["email"];
            $_SESSION["pwd"]=$row["pwd"];
        }     
    } 
    else 
    {
        echo "0 results";
    }
?>
<html>
    <body>
        <form action = "" method = "POST">
            <input type="hidden" name="id" id="id" value=<?php echo $_SESSION["id"] ?>>
            <table>
                <tr>
                    <td><label for = "fname" >First Name:</td>
                    <td><input type = "text" id = "fname" name = "fname" value =<?php echo $_SESSION["fname"]?>></td>               
                </tr>
                <tr>
                    <td><label for = "lname" >Last Name:</td>
                    <td><input type = "text" id = "lname" name = "lname" value =<?php echo $_SESSION["lname"]?>></td>                              
                </tr>
                <tr>
                    <td><label for = "mobile" >Mobile Number:</td>
                    <td><input type = "tel" id = "mobile" name = "mobile" value =<?php echo $_SESSION["mobile"]?>></td>                                
                </tr>
                <tr>
                    <td><label for = "dob" >Date of birth:</td>
                    <td><input type = "date" id = "dob" name = "dob" value =<?php echo $_SESSION["dob"]?>></td>               
                </tr>
                <tr>
                    <td><label for = "uname" >UserName:</td>
                    <td><input type = "text" id = "uname" name = "uname" value =<?php echo $_SESSION["uname"]?>></td>                              
                </tr>
                <tr>
                    <td><label for = "email" >Email:</td>
                    <td><input type = "email" id = "email" name = "email" value =<?php echo $_SESSION["email"]?>></td>                              
                </tr>
                <tr>
                    <td><label for = "pwd" >Password:</td>
                    <td><input type = "text" id = "pwd" name = "pwd" value =<?php echo $_SESSION["pwd"]?>></td>                              
                </tr>
                <tr>
                    <td><input type ="submit" name="update" class="update2" Value="update"></td>
                    <td><a href="utility.php">Back</a></td>
                </tr>

            </table>
            <br>
            
        </form>
        <?php echo $msg ?> 
    </body>
</html>
 

